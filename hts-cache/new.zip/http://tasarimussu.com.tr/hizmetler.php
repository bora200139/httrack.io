<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>TASARIM&Uuml;SS&Uuml; - HÝZMETLER</title>
<meta name="description" content="TASARIMÜSSÜ YASAL WEB SİTESİ"/>
<meta name="keywords" content="Tasarım, Ürün, Ambalaj, Gıda, Marka Yaratma, Tasarım Danışmanlığı, Prototip ve Numune Üretim Hizmetleri"/>

<link href="favicon.ico" rel="shortcut icon"/><link href="src/layout.css" rel="stylesheet">
<link href="src/general.css" rel="stylesheet">
<link href="src/slides.css" rel="stylesheet">
<link href="src/sidebarright_AMB.css" rel="stylesheet">
<link href="src/perfect-scrollbar.css" rel="stylesheet">
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
<script src="src/jquery.mousewheel.js"></script>
<script src="src/perfect-scrollbar.js"></script>

<style type="text/css">

.container {
	padding: 10px;
	height: 660px;
	width: 1024px;
	margin-top: 0px;
	margin-right: auto;
	margin-bottom: 0px;
	margin-left: auto;
	position: relative;
	top: 30px;
}
</style>

<script>
jQuery(document).ready(function ($) {
        "use strict";
        $('#Default').perfectScrollbar();
      });
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
    </script>
    
    
</head>

<body style="overflow: "  body onload="MM_preloadImages('img/menu_studyo_H.png','img/menu_haberler_H.png','img/menu_hizmetler_H.png','img/menu_iletisim_H.png')">

<div class="container">

<div class="sidebar_left"></div>

  <div id="submenu">
  </div>


    <div id="Default" class="contentHolder">
      
       <p>&nbsp;</p><p>&nbsp;</p>
        <p><span style="color: #FFF; font-size: 12px; font-family: Arial, Helvetica, sans-serif;">Ürün ve Ambalaj Tasarımı</span><br />
      <p>İhtiyaçlar doğrultusunda fark yaratan, rekabet avantajı sağlayan, pazara yön veren, üretim ve teknoloji kısıtlarını göz önünde bulunduran, fonksiyonel, estetik, ihtiyacı gözeterek tüketicisine, satışları artırarak üreticisine artı değer kazandıran ürün tasarımları, ambalaj tasarımları ve gıda tasarımları yapılmaktadır.</p>
          <p><span style="color: #FFF; font-size: 12px; font-family: Arial, Helvetica, sans-serif;">Marka Yaratma </span><br />
      <p>Ürün ve marka kimliği oluşturulması için tüketici ile etkili iletişim kuracak,  dikkat çekecek ve akılda kalacak ikonik ürünler tasarlanmakta, ürüne uygun marka adı, kimliği ve stratejisi kurgulanmaktadır. </p>
          <p><span style="color: #FFF; font-size: 12px; font-family: Arial, Helvetica, sans-serif;">Prototip ve Numune Üretim Hizmetleri</span><br />
      <p>Yapılan tasarımların üretimi öncesinde prototip ve numune yapımı konusunda hizmet verilmekte, tedarikçiler ile marka sahibi üreticiler arasında uyumlu çalışmayla zamanı verimli kullanarak başarılı ürünlerin ortaya çıkması sağlanmaya çalışılmaktadır. </p>
          <p><span style="color: #FFF; font-size: 12px; font-family: Arial, Helvetica, sans-serif;">Tasarım Danışmanlığı</span><br />
      <p>Firmalara fark yaratarak rekabet edebilmeleri ve satışlarını artırabilmeleri için tasarım ve pazarlama stratejileri ile ilgili danışmanlık hizmeti verilmektedir. </p>
            
    </div>
        
    <div class="menu"><a href="en/haberler_bizden.php"><img src="img/EN.png" width="26" height="25" alt="tasarimussu_EN" /></a><a href="studyo_felsefe.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('menu_studyo','','img/menu_studyo_H.png',1)"><img src="img/menu_placeholder.gif" alt="" width="60" height="25" /><img src="img/menu_studyo.png" alt="tasarimussu_studyo" width="106" height="25" id="menu_studyo" /></a><img src="img/menu_placeholder.gif" width="27" height="25" /><img src="img/menu_hizmetler_H.png" width="106" height="25" /><img src="img/menu_placeholder.gif" width="35" height="25" /><a href="haberler_bizden.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('menu_haberler','','img/menu_haberler_H.png',1)"><img src="img/menu_haberler.png" alt="tasarimussu_Haberler" width="106" height="25" id="menu_haberler" /></a><img src="img/menu_placeholder.gif" width="27" height="25" /><a href="iletisim.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('menu_iletisim','','img/menu_iletisim_H.png',1)"><img src="img/menu_iletisim.png" alt="tasarimussu_iletisim" width="106" height="25" id="menu_iletisim" /></a><img src="img/menu_placeholder.gif" width="23" height="25" />    <a href="
	
	
portfolyo_amb_50

.php"  onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('menu_portfolyo','','img/menu_portfolyo_H.png',1)"><img src="img/menu_portfolyo.png" alt="tasarimussu_portfolyo" name="menu_portfolyo" width="224" height="25" id="menu_portfolyo" /></a></div>
  
</div>
  
  <div class="turq" id="turq"><a href="http://www.turquality.com/" target="_blank"><img src="img/turquality_1.png" width="240" height="27" alt="turquality" /></a></div>
  
   </div>

  <div class="tt" id="tt"><a href="http://www.tumlesiktasarim.com" target="_blank"><img src="img/tt.png" width="18" height="84" /></a></div>

</body>
</html>
