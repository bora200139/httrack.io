
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>TASARIMÜSSÜ - ÖDÜLLER</title>
<meta name="description" content="TASARIMÜSSÜ YASAL WEB SİTESİ"/>
<meta name="keywords" content="Tasarım, Ürün, Ambalaj, Gıda, Marka Yaratma, Tasarım Danışmanlığı, Prototip ve Numune Üretim Hizmetleri"/>

<link href="favicon.ico" rel="shortcut icon"/><link href="src/layout.css" rel="stylesheet">
<link href="src/general.css" rel="stylesheet">
<link href="src/slides.css" rel="stylesheet">
<link href="src/perfect-scrollbar.css" rel="stylesheet">
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
<script src="src/jquery.mousewheel.js"></script>
<script src="src/perfect-scrollbar.js"></script>

<style type="text/css">

.container {
	padding: 10px;
	height: 660px;
	width: 1024px;
	margin-top: 0px;
	margin-right: auto;
	margin-bottom: 0px;
	margin-left: auto;
	position: relative;
	top: 30px;
}
</style>

<script>
jQuery(document).ready(function ($) {
        "use strict";
        $('#Default').perfectScrollbar();
      });
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
    </script>
    
    
</head>

<body style="overflow: "  body onload="MM_preloadImages('img/menu_studyo_H.png','img/menu_haberler_H.png','img/menu_hizmetler_H.png','img/menu_iletisim_H.png')">

<div class="container">

<div class="sidebar_left"></div>

  <div id="submenu">
    <p><a href="studyo_felsefe.php">FELSEFE</a></p>
    <p><a href="studyo_biyo.php">BİYOGRAFİ</a></p>
    <p><a href="studyo_musteriler.php">MÜŞTERİLER</a></p>
    <p><strong><span style="font-family: Arial, Helvetica, sans-serif; font-size: 10px; color: #FFF">ÖDÜLLER</span></strong></p>
    <p>&nbsp;</p>
    
</div>

  <div id="Default" class="contentHolder">
  <form name="form1" method="post" action="">
 
          <p><span style="color: #fff; font-size: 14px; font-family: Arial, Helvetica, sans-serif;">2016 Ödülleri</span></p>
      <p><p>Red Dot Tasarım Ödülü 2016 - İstanblue Vodka </p>
<p>WPO Worldstar 2016 (WPO:World Packaging Organisation), İstanblue Vodka </p>
<p>WPO Worldstar 2016 (WPO:World Packaging Organisation), Safya - Ayçiçek Yağ </p>
<p>Ambalaj Ay Yıldızları 2016, İçecek Kategorisi, Yetkinlik Ödülü - Yeni Rakı 150 cl </p>
<p>Ambalaj Ay Yıldızları 2016, İçecek Kategorisi, Bronz Ödül - İzmir Rakısı </p>
<p>Design Turkey 2016, İyi Tasarım Ödülü - Eti Sticks </p>
<p>Design Turkey 2016, İyi Tasarım Ödülü - Safya Ayçiçek Yağ </p>
<p>Asiastar 2016 Ödülü, Mey İçki - İzmir Rakısı </p>
<p>Asiastar 2016 Ödülü, Mey İçki - Yeni Rakı 150 cl </p></p>
          <p><span style="color: #fff; font-size: 14px; font-family: Arial, Helvetica, sans-serif;">2015 Ödülleri</span></p>
      <p><p>WPO Worldstar 2015 (WPO:World Packaging Organisation) - Tekirdağ No 10</p>
<p>Ambalaj Ay Yıldızları 2015, İçecek Kategorisi,Yetkinlik Ödülü- İstanblue Vodka </p>
<p>Ambalaj Ay Yıldızları 2015, Gıda Kategorisi,Yetkinlik Ödülü- Safya - Ayçiçek Yağ </p>
<p>Ambalaj Ay Yıldızları 2015, Grafik Tasarım Kategorisi,Yetkinlik Ödülü- Yeni Rakı Rastgele </p>
<p>Asiastar 2015 Ödülleri, Safya - Ayçiçek Yağ </p>
<p>Asiastar 2015 Ödülleri, İstanblue Vodka </p>
</p>
          <p><span style="color: #fff; font-size: 14px; font-family: Arial, Helvetica, sans-serif;">2014 Ödülleri</span></p>
      <p><p>WPO Worldstar 2014 (WPO:World Packaging Organisation) - Asın Farm Zeytinyağı </p><p>Design Turkey 2014 - İyi Tasarım Ödülü - Tekirdağ No 10 </p>
<p>Ambalaj Ay Yıldızları 2014, İçecek Kategorisi,Bronz Ödül- Tekirdağ No 10 </p><p>Design Turkey 2014 - İyi Tasarım Ödülü - Balkovan</p>
<p>Ambalaj Ay Yıldızları 2014, Gıda Kategorisi,Bronz Ödül- Bahçivan Lezzetli Peynir Topları</p>
<p>Gelibolu Yarımadası Tarihi Milli Parkı Odak Alanları Fikir Projesi üçüncülük Ödülü</p>
<p>Observeur du design '14 Label - Efes Pilsen Fıçı Bira Ambalajı</p>
<p>Observeur du design '14 Label - Efes Malt Bira Ambalajı</p>

</p>
          <p><span style="color: #fff; font-size: 14px; font-family: Arial, Helvetica, sans-serif;">2013 Ödülleri</span></p>
      <p> <p>WPO  Worldstar 2013 (World Packaging Organization) - Efes Pilsen Bahara Özel </p>
<p>German Design Award 2013 Nominee - Tekirdağ Rakısı Ailesi</p>
<p>Observeur du design '13 Label - Eti Sütlü Çikolata</p>
<p>Observeur du design '13 Label - Efes Pilsen Bahara Özel</p>
<p>Observeur du design '13 Label - Efes Pilsen Unfiltered</p>
<p>Observeur du design '13 Label - Komili Özel Üretim Cam Zeytinyağı Ambalajı</p>
<p>Ambalaj Ay Yıldızları 2013, Altın Ödül - Asın Farm Zeytinyağı Ambalajı</p>
<p>Ambalaj Ay Yıldızları 2013, Gümüş Ödül - Binboa Limited Edition</p>
<p>Ambalaj Ay Yıldızları 2013, Gümüş Ödül - Efes Malt Bira Ambalajı</p>
<p>Ambalaj Ay Yıldızları 2013, Gümüş Ödül - Efes Pilsen Fıçı Bira Ambalajı</p></p>
          <p><span style="color: #fff; font-size: 14px; font-family: Arial, Helvetica, sans-serif;">2012 Ödülleri</span></p>
      <p><p>Ambalaj Ay Yıldızları 2012, Yetkinlik Ödülü - Efes Pilsen Bahara Özel</p>
<p>Ambalaj Ay Yıldızları 2012, Gümüş Ödül - Efes Pilsen Unfiltered</p>
<p>Observeur du design '12 Label - Tekirdağ Rakısı Ailesi</p>
<p>Observeur du design '12 Label - Eti Tutku Sütlü Çikolata</p>
<p>Observeur du design '12 Label - Eti Karam Bitter Çikolata</p>
<p>Design Turkey 2012 - Üstün Tasarım Ödülü -  Komili Özel Üretim Cam Zeytinyağı Ambalajı</p>
<p>Design Turkey 2012 - İyi Tasarım Ödülü - Binboa Vodka Ambalajı</p>
<p>Design Turkey 2012 - İyi Tasarım Ödülü - Asın Farm Cam Zeytinyağı Ambalajı</p></p>
          <p><span style="color: #fff; font-size: 14px; font-family: Arial, Helvetica, sans-serif;">2011 Ödülleri</span></p>
      <p><p>Ambalaj Ay Yıldızları 2011, İçecek Kategorisi Altın Ödül - Tekirdağ Rakısı Ailesi</p>
<p>Ambalaj Ay Yıldızları 2011, Gıda Kategorisi, Altın Ödül - Komili Özel Ürün Cam Zeytinyağı Ambalajı</p>
<p>Ambalaj Ay Yıldızları 2011, Grafik Tasarım Kategorisi, Gümüş Ödül - Lezzo</p>
<p>Ambalaj Ay Yıldızları 2011, İçecek Kategorisi, Altın Ödül - Binboa Vodka</p>
<p>Ambalaj Ay Yıldızları 2011, Grafik Tasarım Kategorisi, Yetkinlik Ödülü - Hare Anneler Günü Limited Edition</p>
<p>Red Dot Design Awards 2011 - Tekirdağ Rakısı Ailesi</p>
<p>24. TSE Altın Ambalaj Ödülü, 2011 - Komili Özel Ürün Cam Zeytinyağı Ambalajı</p>
<p>24. TSE Altın Ambalaj Ödülü, 2011 -  Lezzo</p>
<p>24. TSE Altın Ambalaj Ödülü, 2011 -  Binboa Vodka</p>
<p>24. TSE Altın Ambalaj Ödülü, 2011 - Hare Yılbaşı Limited Edition</p>
<p>WPO Worldstar 2011 (WPO: World Packaging Organisation) - Komili Özel Ürün Cam Zeytinyağı Ambalajı</p>
<p>WPO Worldstar 2011 (WPO: World Packaging Organisation) - Binboa Vodka</p></p>
          <p><span style="color: #fff; font-size: 14px; font-family: Arial, Helvetica, sans-serif;">2010 Ödülleri</span></p>
      <p><p>23. TSE Altın Ambalaj - Komili Zeytinyağı Pet Ambalaj</p>
<p>23. TSE Altın Ambalaj - Opet Madeni Motoryağı Ambalajı</p>
<p>23. TSE Altın Ambalaj - Altınbaş Rakısı</p>
<p>Design Turkey 'İyi Tasarım Ödülü' - Altınbaş Rakı Şişesi</p>
<p>Design Turkey 'İyi Tasarım Ödülü' - Yeni Rakı Beykoz Serisi</p>
<p>Design Turkey 'İyi Tasarım Ödülü' - Lazer Kapı Kolu</p>
<p>WPO Worldstar 2010 (World Packaging Organisation) -  Opet Madeni  Yağ Ambalajı </p>
<p>WPO Worldstar 2010 (World Packaging Organisation) - Türkiye'nin Zeytinyağı Şişesi</p>
<p>Ambalaj Ay Yıldızları 2010, İçecek Kategorisi Altın Ödül - Altınbaş Rakısı</p>
<p>Ambalaj Ay Yıldızları 2010, İçecek Kategorisi Gümüş Ödül - Yeni Rakı Beykoz</p>
<p>Ambalaj Ay Yıldızları 2010, Gıda Kategorisi Gümüş Ödül - Türkiye'nin Zeytinyağı Şişesi</p>
<p>Ambalaj Ay Yıldızları 2010, Gıda Kategorisi Bronz Ödül - Komili Zeytinyğı Pet Ambalaj</p>
<p>Ambalaj Ay Yıldızları 2010, Otomotiv İhtiyaç Malzemeleri Kategorisi Altın Ödül - Opet Madeni Yağ</p></p>
          <p><span style="color: #fff; font-size: 14px; font-family: Arial, Helvetica, sans-serif;">2009 Ödülleri</span></p>
      <p><p>22. TSE Altın Ambalaj Ödülü -  Yeni Rakı Duty Free Kutusu</p>
<p>22. TSE Altın Ambalaj Ödülü  - Tekirdağ Rakısı Trakya Serisi</p>
<p>WPO Worldstar 2009 (World Packaging Organisation) - Tekirdağ Rakısı Trakya Serisi</p>
<p>Pentawards  Nomination - Tekirdağ Rakısı Altın Serisi</p>
<p>Observeur du design '09 Label- Yeni Rakı Ailesi</p>
</p>
          <p><span style="color: #fff; font-size: 14px; font-family: Arial, Helvetica, sans-serif;">2008 Ödülleri</span></p>
      <p><p>WPO Worldstar 2008 (World Packaging Organisation)- Tekirdağ Rakısı</p>
<p>21. TSE Altın Ambalaj  - Tekirdağ Rakısı</p>
<p>Design Turkey 2008 'İyi Tasarım Ödülü' - Yeni Rakı Ailesi</p>
<p>Design Turkey 2008 'İyi Tasarım Ödülü' - Tekel Cin Ailesi</p>
<p>Design Turkey 2008 'İyi Tasarım Ödülü' - Votka 1967 Ailesi</p>
<p>Design Turkey 2008 'İyi Tasarım Ödülü' - Tekirdağ Rakısı Ailesi</p></p>
          <p><span style="color: #fff; font-size: 14px; font-family: Arial, Helvetica, sans-serif;">2007 Öncesi Ödüller</span></p>
      <p><p>2005</p>

<p>18. TSE Altın Ambalaj - Yeni Rakı Ailesi</p>

<p>2003</p>

<p>Coverings Special Recognition Award</p>

<p>1996</p>

<p>Panelduş 1. Banyo Tasarım Yarışması Birincilik Ödülü</p>

<p>Adres Mobilya Tasarım Ödülü</p></p>
    </FORM>

    </div>

  
 <div class="menu"><a href="en/haberler_bizden.php"><img src="img/EN.png" width="26" height="25" alt="tasarimussu_EN" /></a><img src="img/menu_placeholder.gif" alt="" width="60" height="25" /><img src="img/menu_studyo_H.png" alt="studyo" width="106" height="25" id="menu_studyo" /><img src="img/menu_placeholder.gif" alt="" width="27" height="25" /><a href="hizmetler.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('menu_hizmetler','','img/menu_hizmetler_H.png',1)"><img src="img/menu_hizmetler.png" alt="tasarimussu_Hizmetler" width="106" height="25" id="menu_hizmetler" /></a><img src="img/menu_placeholder.gif" alt="" width="35" height="25" /><a href="haberler_bizden.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('menu_haberler','','img/menu_haberler_H.png',1)"><img src="img/menu_haberler.png" alt="tasarimussu_Haberler" width="106" height="25" id="menu_haberler" /></a><img src="img/menu_placeholder.gif" alt="" width="27" height="25" /><a href="iletisim.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('menu_iletisim','','img/menu_iletisim_H.png',1)"><img src="img/menu_iletisim.png" alt="tasarimussu_Ýletisim" width="106" height="25" id="menu_iletisim" /></a><img src="img/menu_placeholder.gif" alt="" width="23" height="25" /><a href="
	
	
portfolyo_amb_50

.php"  onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('menu_portfolyo','','img/menu_portfolyo_H.png',1)"><img src="img/menu_portfolyo.png" alt="tasarimussu_Portfolyo" name="menu_portfolyo" width="224" height="25" id="menu_portfolyo" /></a></div>
  
  </div>
  
  <div class="turq" id="turq"><a href="http://www.turquality.com/" target="_blank"><img src="img/turquality_1.png" width="240" height="27" alt="turquality" /></a></div>
  
   </div>

  <div class="tt" id="tt"><a href="http://www.tumlesiktasarim.com" target="_blank"><img src="img/tt.png" width="18" height="84" /></a></div>

</body>
</html>
