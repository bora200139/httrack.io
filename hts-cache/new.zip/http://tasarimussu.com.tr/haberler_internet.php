<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>TASARIM&Uuml;SS&Uuml; - INTERNET</title>
<meta name="description" content="TASARIM�SS� YASAL WEB S�TES�"/>
<meta name="keywords" content="Tasar�m,�r�n,Ambalaj,G�da,Marka Yaratma,Tasar�m Dan��manl���,Prototip ve Numune �retim Hizmetleri"/>

<link href="favicon.ico" rel="shortcut icon"/><link href="src/layout.css" rel="stylesheet">
<link href="src/general.css" rel="stylesheet">
<link href="src/slides.css" rel="stylesheet">
<link href="src/sidebarright_AMB.css" rel="stylesheet">
<link href="src/perfect-scrollbar.css" rel="stylesheet">
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
<script src="src/jquery.mousewheel.js"></script>
<script src="src/perfect-scrollbar.js"></script>

<style type="text/css">

.container {
	padding: 10px;
	height: 660px;
	width: 1024px;
	margin-top: 0px;
	margin-right: auto;
	margin-bottom: 0px;
	margin-left: auto;
	position: relative;
	top: 30px;
}

</style>

<script>
jQuery(document).ready(function ($) {
        "use strict";
        $('#Default').perfectScrollbar();
      });
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
    </script>
    
    
</head>

<body style="overflow: "  body onload="MM_preloadImages('img/menu_studyo_H.png','img/menu_haberler_H.png','img/menu_hizmetler_H.png','img/menu_iletisim_H.png')">

<div class="container">

<div class="sidebar_left"></div>

  <div id="submenuhaber">
    <p><a href="haberler_bizden.php">B�ZDEN HABERLER</a></p>
    <p><a href="haberler_basin.php">BASINDA &Ccedil;IKAN</a></p>
        <p><strong><span style="color: #FFF; font-size: 10px; font-family: Arial, Helvetica, sans-serif;">�NTERNETTE &Ccedil;IKAN</span></strong></p>
    <p><a href="haberler_bultenler.php">B&Uuml;LTENLER</a></p>	
  </div>


<div id="Default" class="contentHolder">

<form name="form1" method="post" action="">
                   
 <p>&nbsp;</p>

 
 
          <p><a href="https://www.haberler.com/turk-kahvesi-icin-bir-ilk-10100027-haberi/" target="_blank">www.haberler.com  "Türk Kahvesi İçin Bir İlk!"</a></p>
            <p><a href="http://www.gidahatti.com/gida-sanayi-tasarimlarina-da-design-turkey-2016-odulu-68928/" target="_blank">www.gidahatti.com  "Gıda Sanayi Tasarımlarına da Design Turkey 2016 Ödülü!"</a></p>
            <p><a href="https://www.youtube.com/watch?v=EEMLtCACKlY" target="_blank">www.youtube.com  "Balkovan Reklam Filmi"</a></p>
            <p><a href="https://www.youtube.com/watch?v=uj6oCJ0G13E" target="_blank">www.youtube.com  "Komili Zeytin Yağı Reklam Filmi"</a></p>
            <p><a href="https://www.youtube.com/watch?v=bqktA3BT_RQ" target="_blank">www.youtube.com  "Komili Ayçiçek Yağı Reklam Filmi"</a></p>
            <p><a href="https://www.youtube.com/watch?v=cyg7pm7Uqa4" target="_blank">www.youtube.com  "Yörsan Ayran Reklam Filmi"</a></p>
            <p><a href="https://www.youtube.com/watch?v=4tVLME1-574" target="_blank">www.youtube.com  "Yeni Rakı Bi Büyük Reklam Filmi"</a></p>
            <p><a href="https://www.youtube.com/watch?v=rusL8I_-buo" target="_blank">www.youtube.com  "Eti Petito Reklam Filmi"</a></p>
            <p><a href="https://www.youtube.com/watch?v=TTTfDmpN5rQ" target="_blank">www.youtube.com  "Eti Zaga Reklam Filmi"</a></p>
            <p><a href="https://www.youtube.com/watch?v=oQLZr8U90KA" target="_blank">www.youtube.com  "Eti Keyfince Reklam Filmi"</a></p>
            <p><a href="https://www.youtube.com/watch?v=RgqAP3QOJ3A" target="_blank">www.youtube.com  "Eti Kıvrımlı Ketçaplı Crax Reklam Filmi"</a></p>
            <p><a href="https://www.youtube.com/watch?v=AgeelmF7WRA" target="_blank">www.youtube.com  "Eti Sütlü Çikolata Reklam Filmi - 2"</a></p>
            <p><a href="https://www.youtube.com/watch?v=4yVqghz9Yxg" target="_blank">www.youtube.com  "Eti Sütlü Çikolata Reklam Filmi - 1"</a></p>
            <p><a href="https://www.youtube.com/watch?v=gpZhXJRdiAU" target="_blank">www.youtube.com  "Eti Tutku Çikolata Reklam Filmi"</a></p>
            <p><a href="https://www.youtube.com/watch?v=HXiL5gBvPYc" target="_blank">www.youtube.com  "Eti Karam Reklam Filmi - 3"</a></p>
            <p><a href="https://www.youtube.com/watch?v=XtRMCIOfze4" target="_blank">www.youtube.com  "Eti Karam Reklam Filmi - 2"</a></p>
            <p><a href="https://www.youtube.com/watch?v=uL0ZYyNuPkA" target="_blank">www.youtube.com  "Eti Karam Reklam Filmi - 1"</a></p>
            <p><a href="https://twitter.com/AlgidaTurkiye/status/788329185613873152" target="_blank">www.twitter.com  "Algida Maraş Usulü - Tahin Bal Badem Reklam Filmi"</a></p>
            <p><a href="https://www.youtube.com/watch?v=wEC6k1QkGw4" target="_blank">www.youtube.com  "Türkiye Tasarım Kronolojisi | Deneme - Ambalaj 1. Oturum"</a></p>
            <p><a href="https://www.youtube.com/watch?v=nVdUpDMXgoc" target="_blank">www.youtube.com  "Ambalaj Dünyası TV Programı"</a></p>
            <p><a href="http://www.mimarizm.com/Yarismalar/Detay.aspx?id=51845" target="_blank">www.mimarizm.com "Tasarımüssü imzalı Komili ve Binboa"</a></p>
            <p><a href="http://www.grafiktasarim.org/index.php?option=com_content&view=article&id=698:tasarmuessuenuen-ambalaj-tasarmlar-world-star-2012de-2-oeduel-kazand&catid=35:grafk-tasarim&Itemid=76" target="_blank">www.grafiktasarim.org "Tasarımüssü'nün ambalaj tasarımları."</a></p>
            <p><a href="http://www.mimarizm.com/Yarismalar/Detay.aspx?id=51845" target="_blank">www.mimarizm.com "Tasarmüssü imzalı Komili ve Binboa"</a></p>
            <p><a href="http://www.kobipostasi.net/2011/12/13/tasarimussunun-ambalaj-tasarimlari-world-star-2012de-2-odul-kazandi/" target="_blank">www.kobipostasi.net "Tasarımüssü'nün ambalaj tasarımları"</a></p>
            <p><a href="http://www.arkitera.com/haber/index/detay/tasarimussu-ambalaj-tasarimiyla-red-dot-odulu-kazandi/2513" target="_blank">www.arkitera.com "Tasarımüssü tasarımlarıyla REDDOT ödülü kazandı."</a></p>
            <p><a href="http://www.sabah.com.tr/Ekonomi/2011/01/27/tasarimda_ihracata_basladi" target="_blank">www.sabah.com.tr "Tasarımda ihracata başladı."</a></p>
            <p><a href="http://www.abvizyonu.com/tasarim/gamze-guven-iyi-tasarimda-3-turkiye-2-dunya-odulu-aldi.html" target="_blank">www.kobisektor.com "Tasarımüssü'ne ödül yağıyor."</a></p>
            <p><a href="http://www.abvizyonu.com/tasarim/gamze-guven-iyi-tasarimda-3-turkiye-2-dunya-odulu-aldi.html" target="_blank">www.abvizyonu.com "Tasarımüssü'ne ödül yağıyor."</a></p>
            <p><a href="http://www.evmanya.com/magazin/tasarim-ussu-ritzenhoff-ta-" target="_blank">www.evmanya.com "Tasarımüssü Ritzenhoff'ta"</a></p>
            <p><a href="a href="http://www.trendus.com/tasarim-ussunden-ritzenhoffa/8383"" target="_blank">www.trendus.com  "Tasarım Üssü'nden Ritzenhoff'a"</a></p>
      </FORM>
</div>

  
    <div class="menu"><a href="en/haberler_bizden.php"><img src="img/EN.png" width="26" height="25" alt="tasarimussu_EN" /></a><a href="studyo_felsefe.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('menu_studyo','','img/menu_studyo_H.png',1)"><img src="img/menu_placeholder.gif" alt="" width="60" height="25" /><img src="img/menu_studyo.png" alt="tasarimussu_studyo" width="106" height="25" id="menu_studyo" /></a><img src="img/menu_placeholder.gif" width="27" height="25" /><a href="hizmetler.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('menu_hizmetler','','img/menu_hizmetler_H.png',1)"><img src="img/menu_hizmetler.png" alt="tasarimussu_hizmetler" width="106" height="25" id="menu_hizmetler" /></a><img src="img/menu_placeholder.gif" width="35" height="25" /><img src="img/menu_haberler_H.png" alt="" width="106" height="25" id="menu_haberler" /><img src="img/menu_placeholder.gif" width="27" height="25" /><a href="iletisim.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('menu_iletisim','','img/menu_iletisim_H.png',1)"><img src="img/menu_iletisim.png" alt="tasarimussu_iletisim" width="106" height="25" id="menu_iletisim" /></a><img src="img/menu_placeholder.gif" width="23" height="25" /><a href="
	
	
portfolyo_amb_50

.php"  onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('menu_portfolyo','','img/menu_portfolyo_H.png',1)"><img src="img/menu_portfolyo.png" alt="tasarimussu_portfolyo" name="menu_portfolyo" width="224" height="25" id="menu_portfolyo" /></a></div>
  
  </div>
  
  <div class="turq" id="turq"><a href="http://www.turquality.com/" target="_blank"><img src="img/turquality_1.png" width="240" height="27" alt="turquality" /></a></div>
  
   </div>

  <div class="tt" id="tt"><a href="http://www.tumlesiktasarim.com" target="_blank"><img src="img/tt.png" width="18" height="84" /></a></div>

</body>
</html>
