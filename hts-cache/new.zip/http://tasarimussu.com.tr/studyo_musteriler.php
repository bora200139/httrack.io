
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>TASARIMÜSSÜ - MÜŞTERİLER</title>
<meta name="description" content="TASARIMÜSSÜ YASAL WEB SİTESİ"/>
<meta name="keywords" content="Tasarım, Ürün, Ambalaj, Gıda, Marka Yaratma, Tasarım Danışmanlığı, Prototip ve Numune Üretim Hizmetleri"/>

<link href="favicon.ico" rel="shortcut icon"/><link href="src/layout.css" rel="stylesheet">
<link href="src/general.css" rel="stylesheet">
<link href="src/slides.css" rel="stylesheet">
<link href="src/sidebarright_AMB.css" rel="stylesheet">
<link href="src/perfect-scrollbar.css" rel="stylesheet">
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
<script src="src/jquery.mousewheel.js"></script>
<script src="src/perfect-scrollbar.js"></script>

<style type="text/css">

.container {
	padding: 10px;
	height: 660px;
	width: 1024px;
	margin-top: 0px;
	margin-right: auto;
	margin-bottom: 0px;
	margin-left: auto;
	position: relative;
	top: 30px;
}
</style>

<script>
jQuery(document).ready(function ($) {
        "use strict";
        $('#Default').perfectScrollbar();
      });
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
    </script>
    
    
</head>

<body style="overflow: "  body onload="MM_preloadImages('img/menu_studyo_H.png','img/menu_haberler_H.png','img/menu_hizmetler_H.png','img/menu_iletisim_H.png')">

<div class="container">

<div class="sidebar_left"></div>

  <div id="submenu">
    <p><a href="studyo_felsefe.php">FELSEFE</a>     </p>
    <p><a href="studyo_biyo.php">BİYOGRAFİ</a></p>
    <p><strong><span style="color: #FFF; font-size: 10px; font-family: Arial, Helvetica, sans-serif;">MÜŞTERİLER</span></strong></p>
    <p><a href="studyo_oduller.php">ÖDÜLLER</a></p>
    <p><a href="studyo_biyo.php"></a></p>
  </div>


<div id="Default" class="contentHolder">

<form name="form1" method="post" action="">

         <div id="leftpanel" style="position:absolute;top: 30px; left:0;width:33%;">
      <p><span style="color: #FFF; font-size: 14px; font-family: Arial, Helvetica, sans-serif;">ÜRÜN TASARIMI</span></p>
<p>&nbsp;</p>
    <p>Eti</p>

<p>Ersa Ofis<p>

<p>Atlas Hali</p>

<p>Doğanlar</p>

<p>Ritzenhoff</p>

<p>Bodino</p>

<p>PSL World</p>

<p>BOCCHI</p>

<p>Vitra</p>

<p>Wilco</p>

<p>Sahi</p>





    </div> 
<div id="middlepanel" style="position:absolute;top: 30px; left:33%;right:33%;">     
      <p><span style="color: #FFF; font-size: 14px; font-family: Arial, Helvetica, sans-serif;">AMBALAJ TASARIMI</span></p>
      <p>&nbsp;</p>
      <p>Mey İçki<p>                             

<p>Unilever<p>

<p>Altıparmak<p>

<p>Katia<p>

<p>ATÜ<p>

<p>Efes Pilsen<p>

<p>EST<p>

<p>Bahçıvan<p>

<p>Fawori<p>

<p>SEK<p>

<p>Komili<p>

<p>Balkovan<p>

<p>OPET<p>

<p>Aves<p>

<p>Anadolu Cam<p>

<p>Asın Farm<p>

<p>Lezzo<p>

<p>Yörsan<p>

<p>Tat Yağ<p>

<p>Berrak<p>

<p>Wee Baby<p>

<p>Peyman<p>

<p>GGK Gıda/Humm<p>

<p>Juss<p>

</div> 
<div id="rightpanel" style="position:absolute;right:0;width:33%;"></div>
<img src="img/musteriler.gif" width="550" height="1100" />


</FORM>




</div>
        
<div class="menu"><a href="en/haberler_bizden.php"><img src="img/EN.png" width="26" height="25" alt="tasarimussu_EN" /></a><img src="img/menu_placeholder.gif" alt="" width="60" height="25" /><img src="img/menu_studyo_H.png" alt="studyo" width="106" height="25" id="menu_studyo" /><img src="img/menu_placeholder.gif" alt="" width="27" height="25" /><a href="hizmetler.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('menu_hizmetler','','img/menu_hizmetler_H.png',1)"><img src="img/menu_hizmetler.png" alt="tasarimussu_Hizmetler" width="106" height="25" id="menu_hizmetler" /></a><img src="img/menu_placeholder.gif" alt="" width="35" height="25" /><a href="haberler_bizden.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('menu_haberler','','img/menu_haberler_H.png',1)"><img src="img/menu_haberler.png" alt="tasarimussu_Haberler" width="106" height="25" id="menu_haberler" /></a><img src="img/menu_placeholder.gif" alt="" width="27" height="25" /><a href="iletisim.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('menu_iletisim','','img/menu_iletisim_H.png',1)"><img src="img/menu_iletisim.png" alt="tasarimussu_Ýletisim" width="106" height="25" id="menu_iletisim" /></a><img src="img/menu_placeholder.gif" alt="" width="23" height="25" /><a href="
	
	
portfolyo_amb_50

.php"   onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('menu_portfolyo','','img/menu_portfolyo_H.png',1)"><img src="img/menu_portfolyo.png" alt="tasarimussu_Portfolyo" name="menu_portfolyo" width="224" height="25" id="menu_portfolyo" /></a></div>
  
</div>
  
  <div class="turq" id="turq"><a href="http://www.turquality.com/" target="_blank"><img src="img/turquality_1.png" width="240" height="27" alt="turquality" /></a></div>
  
   </div>

  <div class="tt" id="tt"><a href="http://www.tumlesiktasarim.com" target="_blank"><img src="img/tt.png" width="18" height="84" /></a></div>

</body>
</html>
