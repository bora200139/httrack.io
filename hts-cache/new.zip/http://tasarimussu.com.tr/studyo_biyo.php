
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>TASARIM&Uuml;SS&Uuml; - BİYOGRAFİ</title>
<meta name="description" content="TASARIMÜSSÜ YASAL WEB SİTESİ"/>
<meta name="keywords" content="Tasarım, Ürün, Ambalaj, Gıda, Marka Yaratma, Tasarım Danışmanlığı, Prototip ve Numune Üretim Hizmetleri"/>

<link href="favicon.ico" rel="shortcut icon"/><link href="src/layout.css" rel="stylesheet">
<link href="src/general.css" rel="stylesheet">
<link href="src/slides.css" rel="stylesheet">
<link href="src/sidebarright_AMB.css" rel="stylesheet">
<link href="src/perfect-scrollbar.css" rel="stylesheet">
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
<script src="src/jquery.mousewheel.js"></script>
<script src="src/perfect-scrollbar.js"></script>

<style type="text/css">

.container {
	padding: 10px;
	height: 660px;
	width: 1024px;
	margin-top: 0px;
	margin-right: auto;
	margin-bottom: 0px;
	margin-left: auto;
	position: relative;
	top: 30px;
}
</style>

<script>
jQuery(document).ready(function ($) {
        "use strict";
        $('#Default').perfectScrollbar();
      });
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
    </script>
    
    
</head>

<body style="overflow: "  body onload="MM_preloadImages('img/menu_studyo_H.png','img/menu_haberler_H.png','img/menu_hizmetler_H.png','img/menu_iletisim_H.png')">

<div class="container">

<div class="sidebar_left"></div>

  <div id="submenu">
    <p><a href="studyo_felsefe.php">FELSEFE</a></p>
    <p><strong><span style="font-family: Arial, Helvetica, sans-serif; font-size: 10px; color: #FFF">BİYOGRAFİ</span></strong></p>
    <p><a href="studyo_musteriler.php">MÜŞTERİLER</a></p>
    <p><a href="studyo_oduller.php">ÖDÜLLER</a></p>
    <p>&nbsp;</p>
    
</div>


<div id="Default" class="contentHolder">

        <form name="form1" method="post" action="">
            <table width="520" border="0" cellpadding="0" cellspacing="0">
    <tr>
      <td width="126" valign="top"><img src="../img/teamboss/team_bos1.png" ></td>
      <td width="354" align="left" valign="top"><p><span style="color: #FFF; font-size: 12px; font-family: Arial, Helvetica, sans-serif;">Gülay Gamze GÜVEN / Kurucu / Tasarım Yöneticisi</span></p>
        <p>İstanbul’da yaşayan tasarımcı Gamze Güven, 1987 yılında Orta Doğu Teknik Üniversitesi Endüstri Ürünleri Tasarımı Bölümü'nden mezun olduktan sonra ODTÜ Mimarlık Fakültesi'nde yüksek lisansını tamamlamıştır. Güven, Endüstriyel Tasarımcılar Meslek Kuruluşu ETMK’nın kuruluşundan itibaren yönetim kurullarında görev almış ve Yaratıcı Endüstriler Konseyi Derneği YEKON’un da geçtiğimiz 3 yıl başkan yardımcılığı görevini üstlenmiştir. Ayrıca 1998-2011 yılları arasında İstanbul Bilgi Üniversitesi “Tasarım Kültürü ve Yönetimi Sertifika Programı’nda yarı zamanlı öğretim görevlisi olarak da çalışmıştır. 1990 yılından itibaren serbest tasarımcı olarak çalışan Gamze Güven, son 16 yıldır kurucusu olduğu Tasarım Üssü'nde yönetici ve kreatif direktör olarak çalışmaktadır. Ekibi ile birlikte yerli ve yabancı birçok sektördeki müşterilerine ürün, gıda ve ambalaj tasarımı yapmaktadır.
1996 yılında Endüstriyel tasarım hizmeti vermek üzere şahıs şirketini kuran Gülay Gamze Güven, 1997 yılında İdol Tasarım Limited Şirketi’ni ortağı ile beraber kurdu. 2000 yılında şirketi devralarak adını Tasarım Üssü Limited Şirketi olarak değiştirdi. Tasarım Üssü kurulduğu günden bu yana, pazara yön veren, satışları artıran, fark yaratan yenilikçi tasarımlar oluşturmak hedefiyle çeşitli sektörlerde yerli ve yabancı firmalara ürün tasarımı, ambalaj tasarımı ve gıda tasarımı yapmakta, ayrıca stratejik tasarım danışmanlığı hizmeti vermektedir. Ekibin hizmet verdiği markalar arasında; Diageo -Mey İçki, Eti, Efes, Est, Sek, Komili, Opet, Balkovan, Anadolu Cam, Bahçıvan, Asın Farm, Lezzo, Atlas Halı, Katia, Vitra, Doğanlar, PSL World, Ritzenhoff, Bodino, Bocchi, Wilco, Sutton Group, Unilever gibi firmalar bulunmaktadır. Tasarım Üssü'nde yapılan çalışmaların yüzden fazla tasarım tescili bulunmaktadır. Tasarım Üssü’nün özellikle ambalaj tasarımı ve gıda tasarımı alanlarında ulusal ve uluslararası birçok tasarım ödülü vardır.</p></td>
      </tr>
  </table>
    <table width="520" border="0" cellpadding="0" cellspacing="0">
    <tr>
      <td width="126" valign="top"><img src="../img/teamboss/team_bos7.png" ></td>
      <td width="354" align="left" valign="top"><p><span style="color: #FFF; font-size: 12px; font-family: Arial, Helvetica, sans-serif;">Hamide AKSOY / Yönetici Asistan</span></p>
        <p>1972 İstanbul doğumlu. 1983 yılında Anadolu Hisarı Ortaokul’undan mezen olduktan sonra, ilk iş hayatına 1993 – 1997 tarihleri arasında Promel Bilgisayar firmasında santral operatörü, 1997 – 2005 tarhlerinde Camel Active Almanya  ofisinde ofis asistanı, 2006 – 2010 tarihler arasında İnproda İnsan Kaynakları firmasında bilişim tarafında danışman asistanlığı, 2010 – 2014 tarihleri arasında Omurga Tasarım firmasında müşteri ilişkileri görevinden ayrıldıktan sonra 2014 Temmuz ayında Tasarımüssü ekibine katıldı.</p></td>
      </tr>
  </table>
          </form>
        <p>TASARIM &Uuml;SS&Uuml; EKÝBÝNDE GE&Ccedil;MÝÞTE YER ALANLAR        </p>
                  <table width="520" border="0" cellpadding="0" cellspacing="0">
            <tr>
              <td width="126" align="left" valign="top"> <img src="../img/team_bos0.png" ></td>
              <td width="354" align="left" valign="top"><p><span style="color: #FFF; font-size: 12px; font-family: Arial, Helvetica, sans-serif;">Fulden TOPALOĞžLU</span></p>
                <p>(2010-2011)
Çalıştığı Projeler: Atlas Halı, Eti Sütlü Çikolata, Lezzo, Jokey Plastik, Ritzenhoff My Image Anahtarlık, WeeBaby, Hare (Anneler Günü Limited Edition)</p></td>
            </tr>
          </table><img src="img/menu_placeholder.gif" width="99" height="5">
                    <table width="520" border="0" cellpadding="0" cellspacing="0">
            <tr>
              <td width="126" align="left" valign="top"> <img src="../img/team_bos0.png" ></td>
              <td width="354" align="left" valign="top"><p><span style="color: #FFF; font-size: 12px; font-family: Arial, Helvetica, sans-serif;">Onur KAYA</span></p>
                <p>(2008-2010)
Çalıştığı Projeler: Eti Karam Çikolata, Eti Tutku Çikolata, Balkovan Bal Ambalajı, Komili Zeytinyağı (pet şişe ve cam özel seri), Wilco Gömme Rezervuar, Opet Madeni Yağ Ambalajı, Vodka 1967, Binboa, Bocci Lavabo Dolabı, Doğanlar Kapı Kolları (Lazer), Hare (Yılbaşı Limited Edition 2011), Türkiye'nin Zeytinyağı Şişesi</p></td>
            </tr>
          </table><img src="img/menu_placeholder.gif" width="99" height="5">
                    <table width="520" border="0" cellpadding="0" cellspacing="0">
            <tr>
              <td width="126" align="left" valign="top"> <img src="../img/team_bos0.png" ></td>
              <td width="354" align="left" valign="top"><p><span style="color: #FFF; font-size: 12px; font-family: Arial, Helvetica, sans-serif;">Gülden MALYA</span></p>
                <p>(2006-2008)
Çalıştığı Projeler: Tekirdağ Rakısı Şişesi ve Bardağı, Altınbaş Rakı Şişesi, Yeni Rakı Duty Free Kutusu</p></td>
            </tr>
          </table><img src="img/menu_placeholder.gif" width="99" height="5">
                    <table width="520" border="0" cellpadding="0" cellspacing="0">
            <tr>
              <td width="126" align="left" valign="top"> <img src="../img/team_bos0.png" ></td>
              <td width="354" align="left" valign="top"><p><span style="color: #FFF; font-size: 12px; font-family: Arial, Helvetica, sans-serif;">Zeynep ARMAN</span></p>
                <p>(2005-2006)
Çalıştığı Projeler: Tekel Cin Şişesi, Tekel Vodka Şişesi, Doğanlar Kapı Kolları, Yeni Rakı (Bardak), Vitra (Elektronik Pisuar Kumandası, Çocuk ve Yaşlılar İçin Takım)</p></td>
            </tr>
          </table><img src="img/menu_placeholder.gif" width="99" height="5">
                    <table width="520" border="0" cellpadding="0" cellspacing="0">
            <tr>
              <td width="126" align="left" valign="top"> <img src="../img/team_bos0.png" ></td>
              <td width="354" align="left" valign="top"><p><span style="color: #FFF; font-size: 12px; font-family: Arial, Helvetica, sans-serif;">Aslı BÖRÜ</span></p>
                <p>(2005-2006)
Çalıştığı Projeler: Tekel Cin Şişesi, Tekel Vodka Şişesi, Doğanlar Kapı Kolları, Yeni Rakı (Bardak), Vitra (Elektronik Pisuar Kumandası, Çocuk ve Yaşlılar İçin Takım)</p></td>
            </tr>
          </table><img src="img/menu_placeholder.gif" width="99" height="5">
                    <table width="520" border="0" cellpadding="0" cellspacing="0">
            <tr>
              <td width="126" align="left" valign="top"> <img src="../img/team_bos0.png" ></td>
              <td width="354" align="left" valign="top"><p><span style="color: #FFF; font-size: 12px; font-family: Arial, Helvetica, sans-serif;">Sıla YİĞİT</span></p>
                <p>(2005)
Çalıştığı Projeler: Sönmez Tekstil Fuar Standı, Doğanlar Kapı Kolları, PSL World</p></td>
            </tr>
          </table><img src="img/menu_placeholder.gif" width="99" height="5">
                    <table width="520" border="0" cellpadding="0" cellspacing="0">
            <tr>
              <td width="126" align="left" valign="top"> <img src="../img/team_bos0.png" ></td>
              <td width="354" align="left" valign="top"><p><span style="color: #FFF; font-size: 12px; font-family: Arial, Helvetica, sans-serif;">Mete AHISKA</span></p>
                <p>(2004-2005)
Çalıştığı Projeler: Yeni Rakı Şişesi, PSL World (FM5030 we, x-cross mp3 player), Doğanlar Kapı Kolları (Tork)</p></td>
            </tr>
          </table><img src="img/menu_placeholder.gif" width="99" height="5">
                    <table width="520" border="0" cellpadding="0" cellspacing="0">
            <tr>
              <td width="126" align="left" valign="top"> <img src="../img/team_bos0.png" ></td>
              <td width="354" align="left" valign="top"><p><span style="color: #FFF; font-size: 12px; font-family: Arial, Helvetica, sans-serif;">İrem GÜNGÖR</span></p>
                <p>(2004-2005)
Çalıştığı Projeler: Doğanlar Kapı Kolları (Osmanlı), Özyürür Bakalit (Tencere ve Tava Kulpu), PSL World (X-cross mp3 player), Yeni Rakı Şişesi</p></td>
            </tr>
          </table><img src="img/menu_placeholder.gif" width="99" height="5">
                    <table width="520" border="0" cellpadding="0" cellspacing="0">
            <tr>
              <td width="126" align="left" valign="top"> <img src="../img/team_bos0.png" ></td>
              <td width="354" align="left" valign="top"><p><span style="color: #FFF; font-size: 12px; font-family: Arial, Helvetica, sans-serif;">Aslı Oğuzer AYDOĞAN</span></p>
                <p>(2002- 2004)
Çalıştığı Projeler: PSL World (Star, Space Clock, MrSwing), Doğanlar Kapı Kolları, Vitra Engelli Klozet Takımı, Özyürür Bakalit (Tencere Kulpu, Tava Kulpu, Çaydanlık Kulpu), Main Çelik / Tuna (Almira Tencere Kulpu, Çaydanlık ve Çay Seti), Aypaş (Anahtarlık), Cevisama Valencia (TurkishSeramics Fuar Standları), Coverings-Orlando ve Kbis-Chicago (TurkishCeramics Fuar Standları)</p></td>
            </tr>
          </table><img src="img/menu_placeholder.gif" width="99" height="5">
                    <table width="520" border="0" cellpadding="0" cellspacing="0">
            <tr>
              <td width="126" align="left" valign="top"> <img src="../img/team_bos0.png" ></td>
              <td width="354" align="left" valign="top"><p><span style="color: #FFF; font-size: 12px; font-family: Arial, Helvetica, sans-serif;">Candaş AYDAR </span></p>
                <p>(2006-2007, 2009-2010- 2011-2013) Çalıştığı Projeler: Tekirdağ No 10, Opet Madeni Yağ Ambalajı, Balkovan Bal Ambalajı, Bocchi (Taormina Pro), Tekirdağ Rakısı, Aspen (Bölme Duvar Sistemleri), Binboa Vodka, Altınbaş Rakısı, Türkiye'nin Zeytinyağı Şişesi, Hare(Yılbaşı Limited Edition 2011), Doğanlar Kapı Kolları (Zirve, Elif), Tekirdağ Rakı Bardağı, Eti Karam, Eti Sütlü, Efes Unfiltered, Efes Bahar Birası, Efes Malt</p></td>
            </tr>
          </table><img src="img/menu_placeholder.gif" width="99" height="5">
                    <table width="520" border="0" cellpadding="0" cellspacing="0">
            <tr>
              <td width="126" align="left" valign="top"> <img src="../img/team_bos0.png" ></td>
              <td width="354" align="left" valign="top"><p><span style="color: #FFF; font-size: 12px; font-family: Arial, Helvetica, sans-serif;">Ece GÜNAY</span></p>
                <p>(2001)
Çalıştığı Projeler: Horoz Lojistik Fuar Standı, Denizbank Fuar Standı, Vitra Ürün Teşhir Standı, Vitra Engelli Klozet Takımı</p></td>
            </tr>
          </table><img src="img/menu_placeholder.gif" width="99" height="5">
                    <table width="520" border="0" cellpadding="0" cellspacing="0">
            <tr>
              <td width="126" align="left" valign="top"> <img src="../img/team_bos0.png" ></td>
              <td width="354" align="left" valign="top"><p><span style="color: #FFF; font-size: 12px; font-family: Arial, Helvetica, sans-serif;">Emre BAŞARAN</span></p>
                <p>(2000-2001)
Çalıştığı Projeler: Nurus, Vitra Engelli Klozet Takımı, Aypaş Anahtarlık</p></td>
            </tr>
          </table><img src="img/menu_placeholder.gif" width="99" height="5">
                    <table width="520" border="0" cellpadding="0" cellspacing="0">
            <tr>
              <td width="126" align="left" valign="top"> <img src="../img/team_bos0.png" ></td>
              <td width="354" align="left" valign="top"><p><span style="color: #FFF; font-size: 12px; font-family: Arial, Helvetica, sans-serif;">Emrah ÖZTURAN </span></p>
                <p>(2011-2012) 2011 yılında Tasarımüssü tasarım ekibine katıldı.Çalıştığı Projeler; Atlas Halı, Efes Bahar Birası, Kalenobel, Asın Farm, Jokey Plastik, Efes Pilsen Unfiletered, Yeni Rakı Nostalji Serisi ve 2012 yılında ekipten ayrıldı.</p></td>
            </tr>
          </table><img src="img/menu_placeholder.gif" width="99" height="5">
                    <table width="520" border="0" cellpadding="0" cellspacing="0">
            <tr>
              <td width="126" align="left" valign="top"> <img src="../img/team_bos0.png" ></td>
              <td width="354" align="left" valign="top"><p><span style="color: #FFF; font-size: 12px; font-family: Arial, Helvetica, sans-serif;">Engin HERGÜL</span></p>
                <p>(2012-2014) 2012 yılında Tasarım ekibine katıldı.Tekirdağ No 10, Bodino Smile Mousepad, Lezzo Elma Çayı, Balkovan Bal Ambalajı, Yeni Rakı Duty Free Kutusu, Efes Unfiltered, Ritzenhoff Şarap Kadehi, Anahtarlık ve My Little Darling Expresso Fincan Seti, Efes Malt, Efes Pilsen Fıçı, Tekirdağ Rakısı Ailesi gibi projelerde yer aldı ve 2014 yılında ekipten ayrıldı. </p></td>
            </tr>
          </table><img src="img/menu_placeholder.gif" width="99" height="5">
                    <table width="520" border="0" cellpadding="0" cellspacing="0">
            <tr>
              <td width="126" align="left" valign="top"> <img src="../img/team_bos0.png" ></td>
              <td width="354" align="left" valign="top"><p><span style="color: #FFF; font-size: 12px; font-family: Arial, Helvetica, sans-serif;">Ali Sinan ÖZTÜRK</span></p>
                <p>(2013-2014) Tasarımüssü tasarım ekibine 2013 yılında katıldı, birçok projede yer aldı ve 2014 yılının Temmuz ayında ekipten ayrıldı.</p></td>
            </tr>
          </table><img src="img/menu_placeholder.gif" width="99" height="5">
                    <table width="520" border="0" cellpadding="0" cellspacing="0">
            <tr>
              <td width="126" align="left" valign="top"> <img src="../img/team_bos0.png" ></td>
              <td width="354" align="left" valign="top"><p><span style="color: #FFF; font-size: 12px; font-family: Arial, Helvetica, sans-serif;">Duygu ÖZDURGUT</span></p>
                <p>(2011-2015) Anadolu Üniversitesi (Eskişehir) Endüstriyel Tasarım Bölümü'nden mezun oldu, halen Galatasaray Üniversitesi'nde MBA öğrencisi.Üniversite eğitim hayatı  boyunca Milano Design Week ve i-deco İstanbul Fuarı’nda tasarladığı mobilyalar sergilendi. 2011-2012 yılları arasında ETMK projesinde proje koordinatörü asistanı olarak çalıştı. Ağustos 2012‘de proje yöneticisi olarak Tasarım Üssü ekibine katıldı.
Çalıştığı Projeler: Binboa Yılbaşı Limited Edition 2012, Binboa Yılbaşı Limited Edition 2013, Binboa Sevgililer Günü Limited Edition 2013, Baileys Anneler Günü Limited Edition 2013, Baileys Sevgililer Günü Limited Edition 2014, Baileys Anneler Günü Limited Edition 2014.
</p></td>
            </tr>
          </table><img src="img/menu_placeholder.gif" width="99" height="5">
                    <table width="520" border="0" cellpadding="0" cellspacing="0">
            <tr>
              <td width="126" align="left" valign="top"> <img src="../img/team_bos0.png" ></td>
              <td width="354" align="left" valign="top"><p><span style="color: #FFF; font-size: 12px; font-family: Arial, Helvetica, sans-serif;">Utkan KOZALAN </span></p>
                <p>2015 yılının Nisan ayında ekibe katıldı ve 2015 Ağustos ayında Tasarımüssü ekibinden ayrıldı.</p></td>
            </tr>
          </table><img src="img/menu_placeholder.gif" width="99" height="5">
                    <table width="520" border="0" cellpadding="0" cellspacing="0">
            <tr>
              <td width="126" align="left" valign="top"> <img src="../img/team_bos0.png" ></td>
              <td width="354" align="left" valign="top"><p><span style="color: #FFF; font-size: 12px; font-family: Arial, Helvetica, sans-serif;">Cevat SAYILI</span></p>
                <p>2015 yılının Ocak ayında çalışmaya başladı ve 2015 Eylül ayında Tasarımüssü ekibinden ayrıldı.</p></td>
            </tr>
          </table><img src="img/menu_placeholder.gif" width="99" height="5">
                    <table width="520" border="0" cellpadding="0" cellspacing="0">
            <tr>
              <td width="126" align="left" valign="top"> <img src="../img/team_bos0.png" ></td>
              <td width="354" align="left" valign="top"><p><span style="color: #FFF; font-size: 12px; font-family: Arial, Helvetica, sans-serif;">Müge GÜLER</span></p>
                <p>(2014-2016) Yeditepe Üniversitesi Endüstriyel Tasarım Bölüm’ünden onur derecesi ile mezun oldu. Öğrenciliği süresince, Adnan Serbest Design Stüdyo’da mobilya tasarımı, Arçelik (Tuzla) Ar-ge departmanında elektronik sektöründe, Bun Design’da hediyelik eşya sektöründe deneyim kazandı. Bu süreçte katıldığı workshop ve atölye programları ile mesleki gelişimini devam ettirdi. Mezuniyetinin arından birkaç ay freelancer olarak tasarım sektöründe çalışıp 2014 yılı Nisan ayında Tasarımüssü ekibine katıldı 2016 Nisan ayında ekibimizden ayrılmıştır.</p></td>
            </tr>
          </table><img src="img/menu_placeholder.gif" width="99" height="5">
                    <table width="520" border="0" cellpadding="0" cellspacing="0">
            <tr>
              <td width="126" align="left" valign="top"> <img src="../img/team_bos0.png" ></td>
              <td width="354" align="left" valign="top"><p><span style="color: #FFF; font-size: 12px; font-family: Arial, Helvetica, sans-serif;">Ezgi TAŞÇEVİREN</span></p>
                <p>(2012-2015) Anadolu Üniversitesi (Eskişehir) Endüstriyel Tasarım Bölümü'nden mezun oldu. Öğrencilik döneminde, Vestel (Manisa) ve Beko (İstanbul) firmalarındaki stajları elektronik ürün tasarımı alanında; Aksu Suardi Tasarım ve Mimarlık stüdyosundaki (Milano) uzun dönem stajı ise mobilya ve aydınlatma alanında deneyim kazanmasına yardımcı oldu. 2010 yılında Dream Design Factory'de (İstanbul) tasarım ve proje koordinasyonu alanında çalıştığı sırada serbest olarak ürün ve grafik tasarımları yapmaya devam etti. Eylül 2011'den bu yana, Tasarımüssü tasarım ekibine katıldı, 2015 yılında Tasarımüssü ekibinden ayrıldı.</p></td>
            </tr>
          </table><img src="img/menu_placeholder.gif" width="99" height="5">
                    <table width="520" border="0" cellpadding="0" cellspacing="0">
            <tr>
              <td width="126" align="left" valign="top"><img src="../img/team_bos0.png" ></td>
              <td width="354" align="left" valign="top"><p><span style="color: #FFF; font-size: 12px; font-family: Arial, Helvetica, sans-serif;">Sunguralp ŞOLPAN</span></p>
                <p>(2013-2015) Sunguralp 1990 yılında, Bolu'da doğdu. İstanbul Teknik üniversitesi Endüstri Ürünleri Tasarımı Bölümü'nde lisans eğitimini tamamladı. Eğitimi devam ederken Arçelik ve Tasarım Üssü firmalarında stajlar yaptı. Okul yıllarında ayrıca İTÜ Formula SAE takımının 2014 yılındaki "Formula SAE Italy" yarışında ülkemizi temsil edeceği "Tuna" isimli aracın yapımında baş tasarımcı olarak görev yaptı.Okulun son yılı ve mezun olduktan sonra iki yıl daha Tasarım Üssü firmasında çalıştı ve burada Mey İçki ve ETİ gibi kendi pazarlarının lider firmalarının projelerinde bulunma fırsatı yakaladı.2015 yılında Tasarımüssü ekibinden ayrıldı.
</p></td>
            </tr>
          </table><img src="img/menu_placeholder.gif" width="99" height="5">
                    <table width="520" border="0" cellpadding="0" cellspacing="0">
            <tr>
              <td width="126" align="left" valign="top"><img src="../img/team_bos0.png" ></td>
              <td width="354" align="left" valign="top"><p><span style="color: #FFF; font-size: 12px; font-family: Arial, Helvetica, sans-serif;">Yıldız KAYA</span></p>
                <p>(2015-2016) 2008 yılında Yeditepe Üniversitesi Endüstri Ürünleri Tasarımı Bölümünü tam burslu kazandı.Üniversite hayatı süresince Naif Tasarım Adnan Serbest tasarım ofislerinde staj yaparak mobilya alanında deneyim kazandı.2013 yılında mezun olduktan sonra Empati Reklam Ajansında Endüstri Ürünleri Tasarımcısı olarak çalıştı.2015 Mart ayında Tasarım Üssü ekibine katıldı 2016 Haziran ayında ekibimizden ayrıldı.</p></td>
            </tr>
          </table><img src="img/menu_placeholder.gif" width="99" height="5">
                    <table width="520" border="0" cellpadding="0" cellspacing="0">
            <tr>
              <td width="126" align="left" valign="top"><img src="../img/team_bos0.png" ></td>
              <td width="354" align="left" valign="top"><p><span style="color: #FFF; font-size: 12px; font-family: Arial, Helvetica, sans-serif;">Ülker ARAL</span></p>
                <p>(2014-2016) 2013 yılında Bahçeşehir Üniversitesi Endüstri Ürünleri Tasarımı Bölümünden mezun oldu. Anadolu Cam San. A.Ş. ‘de yaptığı staj esnasında tasarlamış olduğu şarap şişesi üretilmeye hak kazandı. Katılmış olduğu workshoplar ve stajlar sayesinde mobilya, takı ve grafik alanında deneyimler kazandı. 2014 yazında Ritzenhoff markası için Gamze Güven’le birlikte tasarlamış oldukları espresso fincanı üretildi. Eylül ayında Tasarımüssü ekibine katıldı 2016 Mart ayında ekibimizden ayrıldı.</p></td>
            </tr>
          </table><img src="img/menu_placeholder.gif" width="99" height="5">
                    <table width="520" border="0" cellpadding="0" cellspacing="0">
            <tr>
              <td width="126" align="left" valign="top"><img src="../img/team_bos0.png" ></td>
              <td width="354" align="left" valign="top"><p><span style="color: #FFF; font-size: 12px; font-family: Arial, Helvetica, sans-serif;">Burcu GÜLDÜRÜR</span></p>
                <p>(2004-2017) 1980 yılında İstanbul da doğdu.1995 yılında Özdemir Sabancı Lisesinden mezun oldu, 1996-1998 arası Aramel Kozmetik'te stand hostesliği, 1998-2002 arasında Yues Saint Laurent'de make-up uzmanlığı, 2002-2004 Lancome'de güzellik uzmanlığı görevinde bulundu 2004 yılında Tasarımüssü ekibine katıldı ve 2016 Aralık ayında ekibimizden ayrıldı.</p></td>
            </tr>
          </table><img src="img/menu_placeholder.gif" width="99" height="5">
                    <table width="520" border="0" cellpadding="0" cellspacing="0">
            <tr>
              <td width="126" align="left" valign="top"><img src="../img/team_bos0.png" ></td>
              <td width="354" align="left" valign="top"><p><span style="color: #FFF; font-size: 12px; font-family: Arial, Helvetica, sans-serif;">Aslı İrem ATAÇ</span></p>
                <p>(2016 - 2017) 1992 yılında doğdu. Bahçeşehir Üniversitesi Mimarlık ve Tasarım Fakültesi “Endüstri Ürünleri Tasarımı” bölümünden 2014 senesinde mezun olduktan sonra, 2015 senesinde Bahçeşehir Üniversitesi Mimarlık ve Tasarım Fakültesi’nde “Endüstriyel Tasarım ve İnovasyon Yönetimi” yüksek lisans programına girdi ve akademik çalışmalarına devam ediyor. Endüstriyel Tasarım alanındaki çalışmalarının yanında, 2014 senesi itibariyle iş hayatında dünya çapında tanınan bir reklam ajansında Grafik Tasarım alanında da çalışmalar yaptı. Stajlarını Arçelik ve Banat firmalarında tamamlayan Aslı İrem ATAÇ, Tasarım Üssü tasarım ekibine 2016 senesinin Eylül ayında dahil oldu, Aralık 2017 de ekibimizden ayrıldı.</p></td>
            </tr>
          </table><img src="img/menu_placeholder.gif" width="99" height="5">
                    <table width="520" border="0" cellpadding="0" cellspacing="0">
            <tr>
              <td width="126" align="left" valign="top"><img src="../img/team_bos0.png" ></td>
              <td width="354" align="left" valign="top"><p><span style="color: #FFF; font-size: 12px; font-family: Arial, Helvetica, sans-serif;">Selim EROGLU</span></p>
                <p>Kayseri de doğdu.2007 yılında Kayseri Anadolu Güzel Sanatlar lisesinden dereceyle mezun oldu.Bu dönem içerisinde çeşitli yarışmalarda dereceler aldı ve çeşitli sergilere katıldı.2011 yılında Marmara Üni. Endüstri Ürünleri Tasarımı Bölümünü kazandı. Eğitim hayatı süresince çeşitli Tasarım yarışmalarına ve workshoplara katıldı.Kilim mobilyada ve Lüx Plastic şirketlerinde staj yaptı.2015 yılında okuduğu okuldan mezun oldu.Aynı yılın Haziran ayında Tasarımüssü ekibine katıldı ve 2018 yılında ekibimizde ayrıldı.</p></td>
            </tr>
          </table><img src="img/menu_placeholder.gif" width="99" height="5">
                    <table width="520" border="0" cellpadding="0" cellspacing="0">
            <tr>
              <td width="126" align="left" valign="top"> </td>
              <td width="354" align="left" valign="top"><p><span style="color: #FFF; font-size: 12px; font-family: Arial, Helvetica, sans-serif;">Özlem DUYAN / Endüstri Ürünleri Tasarımcısı</span></p>
                <p>1993 yılında doğdu. 2017 yılında Anadolu Üniversitesi, Mimarlık ve Tasarım Fakültesi, Endüstri Ürünleri Tasarımı Bölümü’nden derece ile mezun oldu. Okuduğu yıllar boyunca Anadolu Üniversitesi Tasarım Kulübü’nün, yönetim kurulunda ve grafik ekibinde aktif olarak faaliyet gösterdi. Kulüp ile birlikte birçok etkinliğin organizasyonunda yer aldı. Stajlarını Ford Otosan ve Tasarım Üssü firmalarında tamamladı. Tasarımüssü tasarım ekibine 2017 Eylül ayında dahil oldu.</p></td>
            </tr>
          </table><img src="img/menu_placeholder.gif" width="99" height="5">
                    <table width="520" border="0" cellpadding="0" cellspacing="0">
            <tr>
              <td width="126" align="left" valign="top"> </td>
              <td width="354" align="left" valign="top"><p><span style="color: #FFF; font-size: 12px; font-family: Arial, Helvetica, sans-serif;">Arda ÜLGAY / Endüstri Ürünleri Tasarımcısı</span></p>
                <p>2015 yılında Kadir Has Üniversitesi Endüstriyel Tasarım Bölümü’nden onur derecesi ile mezun olan Arda Ülgay, öğrencilik döneminde ve sonrasında çeşitli kolektif gruplarla birlikte atölyeler, seminerler ve festivallerin organize edilmesine destek olmuştur. Toplum Gönüllüleri Vakfı ile 2012 yılında düzenlenen “Erkeklik İstisnai Bir Durumdur” fotoğraf sergisinde çok sayıda fotoğrafı sergilenen Arda Ülgay, ayrıca otizmli çocuklar için düzenlenen Turkcell Oyuncak Hastanesi projesine katılarak atık oyuncaklardan geri dönüştürülmüş yeni oyuncaklar yaratılmasına katkı sağlamıştır. Sürdürülebilirlik konusu üzerinde çalışmalarını ilerletirken, tasarım felsefesini de bu yönde geliştirmeye devam etmektedir. 2013 yılından itibaren “Sürdürülebilir Yaşam Film Festivali”nin gerçekleştirilmesine destek olarak, daha yaşanabilir bir gelecek için toplumun bilinçlendirilmesine fayda sağlamaktadır. 2015 yılında Endüstriyel Tasarımcı olarak dahil olduğu Tasarımüssü bünyesinde, 2018’de Proje Yöneticisi olarak devam etmektedir. Gamze Güven ile birlikte Ürün, Ambalaj ve Gıda Tasarımı üzerine çalışmalarını sürdürmekte olup Eti, Mey İçki, Pınar, Sütaş, Starbucks, Rapsel, Juss, Şölen ve Unilever birlikte çalıştığı markalardan bazılarıdır. Tasarımüssü ile eşzamanlı olarak kullanıcı deneyimi odaklı Oyun Tasarımı yaparken, kültürel tasarım algısını farklı bir noktaya taşımak ve “Türk Tasarımı” kavramının oluşmasını sağlamak en önemli hedeflerindendir.</p></td>
            </tr>
          </table><img src="img/menu_placeholder.gif" width="99" height="5">
                    <table width="520" border="0" cellpadding="0" cellspacing="0">
            <tr>
              <td width="126" align="left" valign="top"><img src="../img/teamboss/team_bos11.png" ></td>
              <td width="354" align="left" valign="top"><p><span style="color: #FFF; font-size: 12px; font-family: Arial, Helvetica, sans-serif;">Ada RAHVANCI / Endüstri Ürünleri Tasarımcısı</span></p>
                <p>1993 senesi İstanbul doğumlu. 2015 yılında İstanbul Bilgi Üniversitesi Endüstri Ürünleri Tasarımı bölümünden mezun oldu. 2014 yazında Almanya’da Villeroy & Boch firmasında staj yaptı. Mezun olduktan sonra tasarımın farklı alanlarını deneyimlemek istedi. Servis tasarımı ve sosyal medya üzerine çalışmalara başladı. Grafik ve görsel yeteneklerini geliştirmesi ile birlikte 2017 Aralık ayında Tasarımüssü ekibine katıldı.</p></td>
            </tr>
          </table><img src="img/menu_placeholder.gif" width="99" height="5">
                  <p> PROJE BAZLI CALIÞANLAR </p>
                <table width="520" border="0" cellpadding="0" cellspacing="0">
          <tr>
            <td width="126" align="left" valign="top"><img src="../img/team_bos0.png" ></td>
            <td width="354" align="left" valign="top"><p><span style="color: #FFF; font-size: 12px; font-family: Arial, Helvetica, sans-serif;">FAHRİYE ÖZBAY</span></p>
              <p>(2010) Çalıştığı Projeler: Yeni Rakı Beykoz Serisi</p></td>
          </tr>
        </table><img src="img/menu_placeholder.gif" width="99" height="5">
                <table width="520" border="0" cellpadding="0" cellspacing="0">
          <tr>
            <td width="126" align="left" valign="top"><img src="../img/team_bos0.png" ></td>
            <td width="354" align="left" valign="top"><p><span style="color: #FFF; font-size: 12px; font-family: Arial, Helvetica, sans-serif;">İPEK TORUN</span></p>
              <p>(2009) Çalıştığı Projeler: Tekirdağ Rakısı(Grafik Tasarım), Yeni Rakı (Duty Free Grafik Tasarım)</p></td>
          </tr>
        </table><img src="img/menu_placeholder.gif" width="99" height="5">
                <table width="520" border="0" cellpadding="0" cellspacing="0">
          <tr>
            <td width="126" align="left" valign="top"><img src="../img/team_bos0.png" ></td>
            <td width="354" align="left" valign="top"><p><span style="color: #FFF; font-size: 12px; font-family: Arial, Helvetica, sans-serif;">MURAT CELEP</span></p>
              <p>(2009-2010) Çalıştığı Projeler: Komili Zeytinyağı (Zeytinyağı, ayçiçek ve mısırözü yağı pet şişe ve teneke grafik tasarımları), Komili Zeytinyağı Özel Seri Cam Şişe (Grafik Tasarımları)</p></td>
          </tr>
        </table><img src="img/menu_placeholder.gif" width="99" height="5">
                <table width="520" border="0" cellpadding="0" cellspacing="0">
          <tr>
            <td width="126" align="left" valign="top"><img src="../img/team_bos0.png" ></td>
            <td width="354" align="left" valign="top"><p><span style="color: #FFF; font-size: 12px; font-family: Arial, Helvetica, sans-serif;">BAYRAM OKAN YAPICI</span></p>
              <p>(2007, 2009, 2012, 2016) Çalıştığı Projeler: Aspen Bölme Duvar Sistemi Tasarımı, Komili Zeytinyağı (pet şişe), Tasarım Üssü Web Sitesi Tasarımı , Tasarım Üssü Video Sunumu</p></td>
          </tr>
        </table><img src="img/menu_placeholder.gif" width="99" height="5">
                <table width="520" border="0" cellpadding="0" cellspacing="0">
          <tr>
            <td width="126" align="left" valign="top"><img src="../img/team_bos0.png" ></td>
            <td width="354" align="left" valign="top"><p><span style="color: #FFF; font-size: 12px; font-family: Arial, Helvetica, sans-serif;">PINAR ÖNCEL</span></p>
              <p>(2005-2006) Çalıştığı Projeler: Doğanlar Kapı Kolları (Tak Tak, Zümrüt, Park, Olea, Defne, Kavisli, Burç, Kobra, Dilara)</p></td>
          </tr>
        </table><img src="img/menu_placeholder.gif" width="99" height="5">
              </div>

  
<div class="menu"><a href="en/haberler_bizden.php"><img src="img/EN.png" width="26" height="25" alt="tasarimussu_EN" /></a><img src="img/menu_placeholder.gif" alt="" width="60" height="25" /><img src="img/menu_studyo_H.png" alt="studyo" width="106" height="25" id="menu_studyo" /><img src="img/menu_placeholder.gif" alt="" width="27" height="25" /><a href="hizmetler.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('menu_hizmetler','','img/menu_hizmetler_H.png',1)"><img src="img/menu_hizmetler.png" alt="tasarimussu_Hizmetler" width="106" height="25" id="menu_hizmetler" /></a><img src="img/menu_placeholder.gif" alt="" width="35" height="25" /><a href="haberler_bizden.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('menu_haberler','','img/menu_haberler_H.png',1)"><img src="img/menu_haberler.png" alt="tasarimussu_Haberler" width="106" height="25" id="menu_haberler" /></a><img src="img/menu_placeholder.gif" alt="" width="27" height="25" /><a href="iletisim.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('menu_iletisim','','img/menu_iletisim_H.png',1)"><img src="img/menu_iletisim.png" alt="tasarimussu_Ýletisim" width="106" height="25" id="menu_iletisim" /></a><img src="img/menu_placeholder.gif" alt="" width="23" height="25" /><a href="portfolyo_amb_32.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('menu_portfolyo','','img/menu_portfolyo_H.png',1)"><img src="img/menu_portfolyo.png" alt="tasarimussu_Portfolyo" name="menu_portfolyo" width="224" height="25" id="menu_portfolyo" /></a></div>
  
  </div>
  
  <div class="turq" id="turq"><a href="http://www.turquality.com/" target="_blank"><img src="img/turquality_1.png" width="240" height="27" alt="turquality" /></a></div>
  
   </div>

  <div class="tt" id="tt"><a href="http://www.tumlesiktasarim.com" target="_blank"><img src="img/tt.png" width="18" height="84" /></a></div>

</body>
</html>
