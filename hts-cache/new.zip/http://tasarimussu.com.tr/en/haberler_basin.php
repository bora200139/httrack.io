
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>TASARIM&Uuml;SS&Uuml; - PRESS</title>
<meta name="description" content="TASARIM�SS� YASAL WEB S�TES�"/>
<meta name="keywords" content="Tasar�m,�r�n,Ambalaj,G�da,Marka Yaratma,Tasar�m Dan��manl���,Prototip ve Numune �retim Hizmetleri"/>

<link href="favicon.ico" rel="shortcut icon"/><link href="src/layout.css" rel="stylesheet">
<link href="src/general.css" rel="stylesheet">
<link href="src/slides.css" rel="stylesheet">
<link href="src/sidebarright_AMB.css" rel="stylesheet">
<link href="src/perfect-scrollbar.css" rel="stylesheet">
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
<script src="src/jquery.mousewheel.js"></script>
<script src="src/perfect-scrollbar.js"></script>

<style type="text/css">

.container {
	padding: 10px;
	height: 660px;
	width: 1024px;
	margin-top: 0px;
	margin-right: auto;
	margin-bottom: 0px;
	margin-left: auto;
	position: relative;
	top: 30px;
}

</style>

<script>
jQuery(document).ready(function ($) {
        "use strict";
        $('#Default').perfectScrollbar();
      });
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
    </script>
    
    
</head>

<body style="overflow: "  body onload="MM_preloadImages('img/menu_studyo_H.png','img/menu_haberler_H.png','img/menu_hizmetler_H.png','img/menu_iletisim_H.png')">

<div class="container">

<div class="sidebar_left"></div>

<div id="submenuhaber">
  <p><a href="haberler_bizden.php">FROM US</a></p>
  <p><strong>PRESS</strong>
  </p>
  <p><a href="haberler_internet.php">INTERNET</a></p>
  <p><a href="haberler_bultenler.php">BULLETINS</a></p>
</div>


<div id="Default" class="contentHolder">

<form name="form1" method="post" action="">

<p><span style="color: #FFF; font-size: 14px; font-family: Arial, Helvetica, sans-serif;">2016</span></p>
  <p><a href="http://www.tasarimussu.com.tr/pdf/2016/hurrıyetcukurova1.jpg">10.2016 Hürriyet Çukurova</a></p>
    <p><a href="http://www.tasarimussu.com.tr/pdf/2016/gazete.jpg">05.2016 Türkiye Gazetesi</a></p>
    <p><a href="http://www.tasarimussu.com.tr/pdf/2016/hurrıyetcukurova.jpg">05.2016 Hürriyet Çukurova Gazetesi</a></p>
    <p><a href="http://www.tasarimussu.com.tr/pdf/2016/züccaciyedergisi.jpg">03.2016 Züccaciye Dergisi</a></p>
                     
<p><span style="color: #FFF; font-size: 14px; font-family: Arial, Helvetica, sans-serif;">2015</span></p>
  <p><a href="http://www.tasarimussu.com.tr/pdf/2015/toplu.jpg">Mart 2015 Anahtar</a></p>
    <p><span style="color: #FFF; font-size: 14px; font-family: Arial, Helvetica, sans-serif;">2014</span></p>  
  <p><a href="http://www.tasarimussu.com.tr/pdf/2014/toplu.jpg">Mart 2014 Alldesign</a></p>
    <p><span style="color: #FFF; font-size: 14px; font-family: Arial, Helvetica, sans-serif;">2013</span></p>    
            <p><a href="http://www.tasarimussu.com.tr/pdf/2013/001.jpg">Ocak/Şubat/Mart 2013 Ambalaj Dünyası</a></p>
            <p><span style="color: #FFF; font-size: 14px; font-family: Arial, Helvetica, sans-serif;">2012</span></p>
      
                  <p><a href=""></a></p>
       
<p><a href="http://www.tasarimussu.com.tr/pdf/2012/milliyet14032012.jpg" target="_blank">14.03.2012    Milliyet - " K�r�lma sesinden yola &ccedil;�kt�,..."</a></p>
<p><a href="http://www.tasarimussu.com.tr/pdf/2012/sabah14032012.jpg" target="_blank">14.03.2012    Sabah  - &ldquo;Yenilebilir tasar�m Eti'yi...&rdquo;</a></p>
<p><a href="http://www.tasarimussu.com.tr/pdf/2012/vatan14032012.jpg" target="_blank">14.03.2012    Vatan -  &ldquo;&Ouml;d&uuml;ll&uuml; tasar�mc�dan Almanya'ya ihracat&rdquo;</a></p>
<p><a href="http://www.tasarimussu.com.tr/pdf/2012/dunya13012012.jpg" target="_blank">13.01.2012    D&uuml;nya - &ldquo;Tasar�mlar�yla &ouml;d&uuml;lleri toplayan ambalajc�lar&rdquo;</a></p>
<p><a href="http://www.tasarimussu.com.tr/pdf/2012/hp080112012.jpg" target="_blank">08.01.2012    H&uuml;rriyet Pazar - &ldquo;�i�eleri star yap�yor&rdquo;</a></p>







<p><span style="color: #FFF; font-size: 14px; font-family: Arial, Helvetica, sans-serif;">2011</span></p>

       <p><a href=""></a></p>
      

<p><a href="http://www.tasarimussu.com.tr/pdf/2011/13-01032011.pdf" target="_blank">01.03.2011   Maison Francaise  - &ldquo;K&uuml;&ccedil;&uuml;k sevgili&rdquo;</a></p>


<p><a href="http://www.tasarimussu.com.tr/pdf/2011/12-01032011.pdf" target="_blank">01.03.2011   Marketing T&uuml;rkiye -  &ldquo;Eti&rsquo;den ezber bozan &ccedil;ikolata tasar�mlar�&rdquo;</a></p>


<p><a href="http://www.tasarimussu.com.tr/pdf/2011/11-01032011.pdf" target="_blank">01.03.2011   Tasar�m - &ldquo;Binboa Vodka yeni �i�esiyle �imdi &ccedil;ok daha &ccedil;ekici&rdquo;</a></p>


<p><a href="http://www.tasarimussu.com.tr/pdf/2011/10-01032011.pdf" target="_blank">01.03.2011 Capital Ek - &ldquo;5 y�lda 25 tasar�m &ouml;d&uuml;l&uuml;&rdquo;</a></p>


<p><a href="http://www.tasarimussu.com.tr/pdf/2011/08-01022011.pdf" target="_blank">01.02.2011 Maison Francaise -  &ldquo;Muhte�em y&uuml;zy�l&rdquo;</a></p>


<p><a href="http://www.tasarimussu.com.tr/pdf/2011/07-27012011.pdf" target="_blank">27.01.2011 Sabah Ek  - &ldquo;Tasar�mda ihracata ba�lad�.&rdquo;</a></p>


<p><a href="http://www.tasarimussu.com.tr/pdf/2011/06-09012011.pdf" target="_blank">12.01.2011 H&uuml;rses  -  &ldquo;Tasar�m markaya g&uuml;ven veriyor&rdquo;</a></p>

<p><a href="http://www.tasarimussu.com.tr/pdf/2011/04-01012011.pdf" target="_blank">01.01.2011 Z&uuml;ccaciye D&uuml;nyas�nda Focus  - &ldquo;Tasar�m &Uuml;ss&uuml; D&uuml;nya&rsquo;ca ..&rdquo;</a></p>


<p><a href="http://www.tasarimussu.com.tr/pdf/2011/02-01012011.pdf" target="_blank">01.01.2011 Ambalaj Plastik  - &ldquo;Tasar�m &Uuml;ss&uuml;&rsquo;ne &ouml;d&uuml;l ya��yor.&rdquo;</a></p>


<p><a href="http://www.tasarimussu.com.tr/pdf/2011/01-01012011.pdf" target="_blank">01.01.2011 Varanla Yol Boyunca  - &ldquo;Lezzetli tasar�m tutkuyla mayalan�r.&rdquo;</a></p>


<p><span style="color: #FFF; font-size: 14px; font-family: Arial, Helvetica, sans-serif;">2010</span></p>
<p><a href="http://www.tasarimussu.com.tr/pdf/2010/02-01122010.pdf" target="_blank">01.12.2010  Home Art  -  &ldquo;Ritzenhoff&rsquo;a T&uuml;rk �mzas�&rdquo;</a></p>
<p><a href="http://www.tasarimussu.com.tr/pdf/2010/01-10102010.pdf" target="_blank">10.10.2010  Matbaa Haber  -  &ldquo;Alt�nba� rak� ambalaj�&rdquo;</a></p>
<p><span style="color: #FFF; font-size: 14px; font-family: Arial, Helvetica, sans-serif;">2009</span></p>
<p><a href="http://www.tasarimussu.com.tr/pdf/2009/07-09122009.pdf" target="_blank">09.12.2009  Ayr�nt�l� Haber  - &ldquo;T&uuml;rk ambalaj� D&uuml;nya y�ld�z�&rdquo;</a></p>
<p><a href="http://www.tasarimussu.com.tr/pdf/2009/02-09122009.pdf" target="_blank">09.12.2009  Ba�kent  -  &ldquo;T&uuml;rk ambalaj firmalar� D&uuml;nya y�ld�z� se&ccedil;ildi.&rdquo;</a></p>
<p><a href="http://www.tasarimussu.com.tr/pdf/2009/03-09122009.pdf" target="_blank">09.12.2009  Cumhuriyet -  &ldquo;10 T&uuml;rk firmas� ambalajda D&uuml;nya y�ld�z� oldu.&rdquo;</a></p>
<p><span style="color: #FFF; font-size: 14px; font-family: Arial, Helvetica, sans-serif;">2008</span></p>
<p><a href="http://www.tasarimussu.com.tr/pdf/2008/05-102008.pdf" target="_blank">10.2008 XXI  - &ldquo;i&ccedil;imi yumu�ak �i�e&rdquo;</a></p>
<p><a href="http://www.tasarimussu.com.tr/pdf/2008/04-112008.pdf" target="_blank">11.2008 Turkish Time  - &ldquo;Tasar�m�n y�ld�zlar�&rdquo;</a></p>
<p><a href="http://www.tasarimussu.com.tr/pdf/2008/03-102008.pdf" target="_blank">10.2008 Elle D&eacute;cor  - &ldquo;T&uuml;rk Tasa�mc�lar&rdquo;</a></p>
<p><a href="http://www.tasarimussu.com.tr/pdf/2008/02-062008.pdf" target="_blank">06.2008 Maison Fran&ccedil;aise  - &ldquo;Gamze G&uuml;ven&rdquo;</a></p>
<p><a href="http://www.tasarimussu.com.tr/pdf/2008/01-012008.pdf" target="_blank">01.2008 Wohnrevue  - &ldquo;Tasar�m &Uuml;ss&uuml; : Gamze G&uuml;ven&rdquo;</a></p>
<p><span style="color: #FFF; font-size: 14px; font-family: Arial, Helvetica, sans-serif;">2007</span></p>
<p><a href="http://www.tasarimussu.com.tr/pdf/2007/13-102007.pdf" target="_blank">10.2007 Marie Claire Maison  - &ldquo;Tasar�m D&uuml;nyas�ndan son dedikodular&rdquo;</a></p>
<p><a href="http://www.tasarimussu.com.tr/pdf/2007/12-102007.pdf" target="_blank">10.2007 Maison Fran&ccedil;aise  - &ldquo;Sergi : Barbarlar Sofras�&rdquo;</a></p>
<p><a href="http://www.tasarimussu.com.tr/pdf/2007/11-102007.pdf" target="_blank">10.2007 Livingetc  - &ldquo;Tasar�m�n Barbarlar�&rdquo;</a></p>
<p><a href="http://www.tasarimussu.com.tr/pdf/2007/10-102007.pdf" target="_blank">10.2007 Icon  - &ldquo;Barbarlar Sofras�&rdquo;</a></p>
<p><a href="http://www.tasarimussu.com.tr/pdf/2007/09-102007.pdf" target="_blank">10.2007 Elle Decor  - &ldquo;Barbarlar Sofras�&rdquo;</a></p>
<p><a href="http://www.tasarimussu.com.tr/pdf/2007/08-092007.pdf" target="_blank">09.2007 Mekan Art�  - &ldquo;Barbarlar Sofras�&rdquo;</a></p>
<p><a href="http://www.tasarimussu.com.tr/pdf/2007/07-092007.pdf" target="_blank">09.2007 Home Art  - &ldquo;&Ccedil;ocuktum ufac�kt�m&rdquo;</a></p>
<p><a href="http://www.tasarimussu.com.tr/pdf/2007/06-072007.pdf" target="_blank">07.2007 XXI  - &ldquo;Gamze G&uuml;ven&rdquo;</a></p>
<p><a href="http://www.tasarimussu.com.tr/pdf/2007/05-072007.pdf" target="_blank">07.2007 Icon  - &ldquo;Corian&rdquo;</a></p>
<p><a href="http://www.tasarimussu.com.tr/pdf/2007/04-062007.pdf" target="_blank">06.2007 Icon  - &ldquo;Bu tasar�m T&uuml;rk m&uuml;ym&uuml;� ?&rdquo;</a></p>
<p><a href="http://www.tasarimussu.com.tr/pdf/2007/03-052007.pdf" target="_blank">05.2007 Maison Fran&ccedil;aise  - "ilk in Milano"</a></p>
<p><a href="http://www.tasarimussu.com.tr/pdf/2007/02-052007.pdf" target="_blank">05.2007 Elle Decor  - &ldquo;Ba�ka olur ilk&rsquo;in heyecan�&rdquo;</a></p>
<p><a href="http://www.tasarimussu.com.tr/pdf/2007/01-052007.pdf" target="_blank">05.2007 Abitare  - &ldquo;Turkish touch in Milano&rdquo;</a></p>
<p><span style="color: #FFF; font-size: 14px; font-family: Arial, Helvetica, sans-serif;">2006</span></p>
<p><a href="http://www.tasarimussu.com.tr/pdf/2006/03-062006.pdf" target="_blank">06.2006 Elle Decor  - &ldquo;Suyla ilgili bir &uuml;r&uuml;n tasarlamak ho�uma gidiyor."</a></p>
<p><a href="http://www.tasarimussu.com.tr/pdf/2006/01-012006.pdf" target="_blank">01.2006 Super  - "Ay�n tasar�mc�s� : Gamze G&uuml;ven."</a></p>
<p><span style="color: #FFF; font-size: 14px; font-family: Arial, Helvetica, sans-serif;">2005</span></p>
<p><a href="http://www.tasarimussu.com.tr/pdf/2005/05-122005.pdf" target="_blank">12.2005 Promot&uuml;rk  - &ldquo;Promosyonda innovasyon �art&rdquo;
</a>
<p><a href="http://www.tasarimussu.com.tr/pdf/2005/04-092005.pdf" target="_blank">09.2005 Elle D&eacute;cor  - &ldquo;&Ccedil;al��ma odas� yorucu olmamal�&rdquo;
</a>
<p><a href="http://www.tasarimussu.com.tr/pdf/2005/03-072005.pdf" target="_blank">07.2005 Milliyet  - &ldquo;Yeni Rak�&rdquo;
</a>
<p><a href="http://www.tasarimussu.com.tr/pdf/2005/02-062005.pdf" target="_blank">06.2005 Tempo  - &ldquo;Rak� �i�esinde kad�n endam�&rdquo;
</a>
<p><a href="http://www.tasarimussu.com.tr/pdf/2005/01-022005.pdf" target="_blank">02.2005 Arma�an  - &ldquo;Tasar�m &Uuml;ss&uuml;&rdquo;

</a>
<p><span style="color: #FFF; font-size: 14px; font-family: Arial, Helvetica, sans-serif;">2004</span></p>
<p><a href="http://www.tasarimussu.com.tr/pdf/2004/02-082004.pdf" target="_blank">08.2004 Marie Claire Maison  - &ldquo;Do�udan bat�ya do�ru&rdquo; </a></p>
<p><a href="http://www.tasarimussu.com.tr/pdf/2004/01-042004.pdf" target="_blank">04.2004 Maison Fran&ccedil;aise  - &ldquo;Geri d&ouml;n&uuml;�&uuml;m&rdquo; </a></p>
<p><a href="http://www.tasarimussu.com.tr/pdf/2003/06-102003.pdf" target="_blank">10.2003 AD  - &ldquo;S�n�rlar�n &ouml;tesine&rdquo; </a></p>
<p><a href="http://www.tasarimussu.com.tr/pdf/2003/05-072003.pdf" target="_blank">07.2003 Sabah Pazar  -&ldquo;Tasar�mc�lar geliyor&rdquo; </a></p>
<p><a href="http://www.tasarimussu.com.tr/pdf/2003/02-062003.pdf" target="_blank">06.2003 Marie Claire Maison  - &ldquo;Tasar�m &Uuml;ss&uuml;&rsquo;nde&rdquo; </a></p>
<p><a href="http://www.tasarimussu.com.tr/pdf/2003/01-062003.pdf" target="_blank">06.2003 Akt&uuml;el Para  - &ldquo;Gamze T&uuml;rko�lu Hong Kong&rsquo;a &ccedil;al���yor&rdquo; </a></p>
<p><a href="http://www.tasarimussu.com.tr/pdf/2002/02-022002.pdf" target="_blank">02.2002 Espas Tasar�m  - &ldquo;Gamze Akay&rdquo; </a></p>
<p><a href="http://www.tasarimussu.com.tr/pdf/2002/01-012002.pdf" target="_blank">01.2002 Art D&eacute;cor  - &ldquo;Gamze Akay&rdquo; </a></p>
<p><a href="http://www.tasarimussu.com.tr/pdf/2001/01-122001.pdf" target="_blank">12.2001 Country Homes  - &ldquo;Gamze Akay&rdquo; </a></p>
<p><a href="http://www.tasarimussu.com.tr/pdf/1999/01-011999.pdf" target="_blank">01.1999 Arredamento Mimarl�k  - &ldquo;Desiners&rsquo; Odyssey&rdquo; </a></p>
<p><a href="http://www.tasarimussu.com.tr/pdf/01-041996.pdf" target="_blank">04.1996 Art Decor -  "2. ulusal tasar�m kongresi" </a></p>
</FORM>
</div>

  
    <div class="menu"><a href="../haberler_bizden.php"><img src="img/EN.png" width="26" height="25" alt="tasarimussu_EN" /></a><a href="studyo_felsefe.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('menu_studyo','','img/menu_studyo_H.png',1)"><img src="img/menu_placeholder.gif" alt="" width="60" height="25" /><img src="img/menu_studyo.png" alt="tasarimussu_studyo" width="106" height="25" id="menu_studyo" /></a><img src="img/menu_placeholder.gif" width="27" height="25" /><a href="hizmetler.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('menu_hizmetler','','img/menu_hizmetler_H.png',1)"><img src="img/menu_hizmetler.png" alt="tasarimussu_hizmetler" width="106" height="25" id="menu_hizmetler" /></a><img src="img/menu_placeholder.gif" width="35" height="25" /><img src="img/menu_haberler_H.png" alt="" width="106" height="25" id="menu_haberler" /><img src="img/menu_placeholder.gif" width="27" height="25" /><a href="iletisim.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('menu_iletisim','','img/menu_iletisim_H.png',1)"><img src="img/menu_iletisim.png" alt="tasarimussu_iletisim" width="106" height="25" id="menu_iletisim" /></a><img src="img/menu_placeholder.gif" width="23" height="25" /><a href="
	
	
portfolyo_amb_50

.php"  onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('menu_portfolyo','','img/menu_portfolyo_H.png',1)"><img src="img/menu_portfolyo.png" alt="tasarimussu_portfolyo" name="menu_portfolyo" width="224" height="25" id="menu_portfolyo" /></a></div>
  
  </div>
  
  <div class="turq" id="turq"><a href="http://www.turquality.com/" target="_blank"><img src="img/turquality_1.png" width="240" height="27" alt="turquality" /></a></div>
  
   </div>

  <div class="tt" id="tt"><a href="http://www.tumlesiktasarim.com" target="_blank"><img src="img/tt.png" width="18" height="84" /></a></div>

</body>
</html>
