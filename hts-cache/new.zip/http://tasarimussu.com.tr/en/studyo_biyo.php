
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>TASARIM&Uuml;SS&Uuml; - BIOGRAPHIES</title>
<meta name="description" content="TASARIM�SS� YASAL WEB S�TES�"/>
<meta name="keywords" content="Tasar�m,�r�n,Ambalaj,G�da,Marka Yaratma,Tasar�m Dan��manl���,Prototip ve Numune �retim Hizmetleri"/>

<link href="favicon.ico" rel="shortcut icon"/><link href="src/layout.css" rel="stylesheet">
<link href="src/general.css" rel="stylesheet">
<link href="src/slides.css" rel="stylesheet">
<link href="src/sidebarright_AMB.css" rel="stylesheet">
<link href="src/perfect-scrollbar.css" rel="stylesheet">
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
<script src="src/jquery.mousewheel.js"></script>
<script src="src/perfect-scrollbar.js"></script>

<style type="text/css">

.container {
	padding: 10px;
	height: 660px;
	width: 1024px;
	margin-top: 0px;
	margin-right: auto;
	margin-bottom: 0px;
	margin-left: auto;
	position: relative;
	top: 30px;
}
</style>

<script>
jQuery(document).ready(function ($) {
        "use strict";
        $('#Default').perfectScrollbar();
      });
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
    </script>
    
    
</head>

<body style="overflow: "  body onload="MM_preloadImages('img/menu_studyo_H.png','img/menu_haberler_H.png','img/menu_hizmetler_H.png','img/menu_iletisim_H.png')">

<div class="container">

<div class="sidebar_left"></div>

  <div id="submenu">
    <p><a href="studyo_felsefe.php">PHILOSOPHY</a></p>
    <p><strong><span style="font-family: Arial, Helvetica, sans-serif; font-size: 10px; color: #FFF">BIOGRAPHIES</span></strong></p>
    <p><a href="studyo_musteriler.php">CUSTOMERS</a></p>
    <p><a href="studyo_oduller.php">AWARDS</a></p>
    <p>&nbsp;</p>
    
</div>


<div id="Default" class="contentHolder">

        <form name="form1" method="post" action="">
            <table width="520" border="0" cellpadding="0" cellspacing="0">
    <tr>
      <td width="126" valign="top"><img src="../img/teamboss/team_bos1.png" ></td>
      <td width="354" align="left" valign="top"><p><span style="color: #FFF; font-size: 12px; font-family: Arial, Helvetica, sans-serif;">Gülay Gamze GÜVEN / Kurucu / Tasarım Yöneticisi</span></p>
        <p>Gamze Guven, designer in Istanbul, studied industrial design in Middle East Technical University and completed her MSc in 1990 in the Faculty of Architecture at the same university. She had worked for a decade both as a board member of the Industrial Designers’ Society of Turkey (ETMK) various times and also she was the Vice-President of Creative Industries of Turkey last 3 years. She worked as a part time instructor in Bilgi University Design Culture and Management Certificate Program between 1998-2011. Since the early 90s she has been working as a manager and creative director in her company Tasarım Üssü Ltd. With her team she is undertaking industrial design, food design and packaging design projects in different sectors for a number of local and international companies.
Gamze Güven, who founded the industrial design service purposed company in 1996, co-founded  İdol Tasarım Ltd Co in 1997 with her associate. In the year of 2000 she took over the company and renamed it Tasarımüssü Ltd Co. Since the day Tasarımüssü was founded, it has been shaping the market, increasing the sale-rates and always aiming to make innovative designs. Company works in various sectors, serving product design, packaging design and food design to national and international firms. Tasarımüssü also has strategic design consultancy service. Diageo-Mey Icki, Eti, Efes, Est, Sek, Komili, Balkovan, Opet, Anadolu cam, Bahçıvan, Fawori, Lezzo, Atlas Halı, Vitra, Doğanlar, PSL World, Sutton Group, Bodino, Ritzenhoff, Bocchi, Wilco, Asın Farm, Bahcivan are some of the firms that Tasarımüssü works with. The works which are made by Tasarımüssü have over hundered official design patents. Tasarımüssü has a significant amounth of national an international awards especially in packaging design and food design. </p></td>
      </tr>
  </table>
    <table width="520" border="0" cellpadding="0" cellspacing="0">
    <tr>
      <td width="126" valign="top"><img src="../img/teamboss/team_bos7.png" ></td>
      <td width="354" align="left" valign="top"><p><span style="color: #FFF; font-size: 12px; font-family: Arial, Helvetica, sans-serif;">Hamide AKSOY / Yönetici Asistan</span></p>
        <p>1972 İstanbul doğumlu. 1983 yılında Anadolu Hisarı Ortaokul’undan mezen olduktan sonra, ilk iş hayatına 1993 – 1997 tarihleri arasında Promel Bilgisayar firmasında santral operatörü, 1997 – 2005 tarhlerinde Camel Active Almanya  ofisinde ofis asistanı, 2006 – 2010 tarihler arasında İnproda İnsan Kaynakları firmasında bilişim tarafında danışman asistanlığı, 2010 – 2014 tarihleri arasında Omurga Tasarım firmasında müşteri ilişkileri görevinden ayrıldıktan sonra 2014 Temmuz ayında Tasarımüssü ekibine katıldı.</p></td>
      </tr>
  </table>
          </form>
        <p>PAST TEAM PARTNERS</p>
                  <table width="520" border="0" cellpadding="0" cellspacing="0">
            <tr>
              <td width="126" align="left" valign="top"> <img src="../img/team_bos0.png" ></td>
              <td width="354" align="left" valign="top"><p><span style="color: #FFF; font-size: 12px; font-family: Arial, Helvetica, sans-serif;">Fulden TOPALOĞžLU</span></p>
                <p>(2010-2011)
Projects she worked in: Atlas Carpet, Eti Milky Chocolate, Lezzo, Jokey Plastik, Ritzenhoff My Image, WeeBaby, Hare (Mothers Day Limited Edition)</p></td>
            </tr>
          </table><img src="img/menu_placeholder.gif" width="99" height="5">
                    <table width="520" border="0" cellpadding="0" cellspacing="0">
            <tr>
              <td width="126" align="left" valign="top"> <img src="../img/team_bos0.png" ></td>
              <td width="354" align="left" valign="top"><p><span style="color: #FFF; font-size: 12px; font-family: Arial, Helvetica, sans-serif;">Onur KAYA</span></p>
                <p>(2008-2010)
Projects he worked in: Eti Karam Chocolate, Eti Tutku Chocolate, Balkovan Honey Package, Komili Olive Oil (pet bottle and glass special edition), Wilco Concealed Cistern, Opet Mineral Oil Package, Vodka 1967, Binboa, Bocci Sink Closet, Doğanlar Door Handles (Lazer), Hare (Christmas Limited Edition 2011), Turkey's Olive Oil Bottle</p></td>
            </tr>
          </table><img src="img/menu_placeholder.gif" width="99" height="5">
                    <table width="520" border="0" cellpadding="0" cellspacing="0">
            <tr>
              <td width="126" align="left" valign="top"> <img src="../img/team_bos0.png" ></td>
              <td width="354" align="left" valign="top"><p><span style="color: #FFF; font-size: 12px; font-family: Arial, Helvetica, sans-serif;">Gülden MALYA</span></p>
                <p>(2006-2008)
Projects she worked in: Tekirdağ Rakı Bottle and Glass, Altınbaş Rakı Bottle, Yeni Rakı Duty Free Box</p></td>
            </tr>
          </table><img src="img/menu_placeholder.gif" width="99" height="5">
                    <table width="520" border="0" cellpadding="0" cellspacing="0">
            <tr>
              <td width="126" align="left" valign="top"> <img src="../img/team_bos0.png" ></td>
              <td width="354" align="left" valign="top"><p><span style="color: #FFF; font-size: 12px; font-family: Arial, Helvetica, sans-serif;">Zeynep ARMAN</span></p>
                <p>(2005-2006)
Projects she worked in: Tekel Cin Bottle, Tekel Vodka Bottle, Doğanlar Door Handles, Yeni Rakı (Glass), Vitra (Elektronik Pissoir Control Panel, Toilet for Children and Elderly)</p></td>
            </tr>
          </table><img src="img/menu_placeholder.gif" width="99" height="5">
                    <table width="520" border="0" cellpadding="0" cellspacing="0">
            <tr>
              <td width="126" align="left" valign="top"> <img src="../img/team_bos0.png" ></td>
              <td width="354" align="left" valign="top"><p><span style="color: #FFF; font-size: 12px; font-family: Arial, Helvetica, sans-serif;">Aslı BÖRÜ</span></p>
                <p>(2005-2006)
Projects she worked in: Tekel Cin Bottle, Tekel Vodka Bottle, Doğanlar Door Handles, Yeni Rakı (Glass), Vitra (Elektronik Pissoir Control Panel, Toilet for Children and Elderly)</p></td>
            </tr>
          </table><img src="img/menu_placeholder.gif" width="99" height="5">
                    <table width="520" border="0" cellpadding="0" cellspacing="0">
            <tr>
              <td width="126" align="left" valign="top"> <img src="../img/team_bos0.png" ></td>
              <td width="354" align="left" valign="top"><p><span style="color: #FFF; font-size: 12px; font-family: Arial, Helvetica, sans-serif;">Sıla YİĞİT</span></p>
                <p>(2005)
Projects she worked in: Sönmez Tekstil Fair Stand,Doğanlar Door Handles, PSL World</p></td>
            </tr>
          </table><img src="img/menu_placeholder.gif" width="99" height="5">
                    <table width="520" border="0" cellpadding="0" cellspacing="0">
            <tr>
              <td width="126" align="left" valign="top"> <img src="../img/team_bos0.png" ></td>
              <td width="354" align="left" valign="top"><p><span style="color: #FFF; font-size: 12px; font-family: Arial, Helvetica, sans-serif;">Mete AHISKA</span></p>
                <p>(2004-2005)
Projects he worked in: Yeni Rakı Bottle, PSL World (FM5030 we, x-cross mp3 player), Doğanlar Door Handles (Tork)</p></td>
            </tr>
          </table><img src="img/menu_placeholder.gif" width="99" height="5">
                    <table width="520" border="0" cellpadding="0" cellspacing="0">
            <tr>
              <td width="126" align="left" valign="top"> <img src="../img/team_bos0.png" ></td>
              <td width="354" align="left" valign="top"><p><span style="color: #FFF; font-size: 12px; font-family: Arial, Helvetica, sans-serif;">İrem GÜNGÖR</span></p>
                <p>(2004-2005)
Projects she worked in: Doğanlar Door Handles (Osmanlı),Özyürür Bakalit (Pan Handles), PSL World (X-cross mp3 player), Yeni Rakı Bottle</p></td>
            </tr>
          </table><img src="img/menu_placeholder.gif" width="99" height="5">
                    <table width="520" border="0" cellpadding="0" cellspacing="0">
            <tr>
              <td width="126" align="left" valign="top"> <img src="../img/team_bos0.png" ></td>
              <td width="354" align="left" valign="top"><p><span style="color: #FFF; font-size: 12px; font-family: Arial, Helvetica, sans-serif;">Aslı Oğuzer AYDOĞAN</span></p>
                <p>(2002- 2004)
Projects she worked in: PSL World (Star, Space Clock, MrSwing), Doğanlar Door Handles, Vitra Disabled Toilet, Özyürür Bakalit (Pan and Teapot Handles), Main Çelik / Tuna (Almira Pan Hadle, Teapot and Tea Set), Cevisama Valencia (TurkishSeramics Fair Stand), Coverings-Orlando ve Kbis-Chicago (TurkishCeramics Fair Stand)</p></td>
            </tr>
          </table><img src="img/menu_placeholder.gif" width="99" height="5">
                    <table width="520" border="0" cellpadding="0" cellspacing="0">
            <tr>
              <td width="126" align="left" valign="top"> <img src="../img/team_bos0.png" ></td>
              <td width="354" align="left" valign="top"><p><span style="color: #FFF; font-size: 12px; font-family: Arial, Helvetica, sans-serif;">Candaş AYDAR </span></p>
                <p>(2006-2007, 2009-2010- 2011-2013) Projects he worked in: Tekirdağ No 10, Opet Mineral Oil Package, Balkovan Honey Package, Bocchi (Taormina Pro), Tekirdağ Rakı, Aspen (Seperated Wall Systems), Binboa Vodka, Altınbaş Rakı, Turkey's Olive Oil Bottle, Hare (Christmas Limited Edition 2011), Doğanlar Door Handles (Zirve, Elif), Tekirdağ Rakı Glass, Eti Karam Chocolate, Eti Milky Chocolate, Efes Unfiltered Beer, Efes Spring Beer, Efes Malt Beer</p></td>
            </tr>
          </table><img src="img/menu_placeholder.gif" width="99" height="5">
                  <p> TEAM PARTNERS FOR PROJECTS</p>
                <table width="520" border="0" cellpadding="0" cellspacing="0">
          <tr>
            <td width="126" align="left" valign="top"><img src="../img/team_bos0.png" ></td>
            <td width="354" align="left" valign="top"><p><span style="color: #FFF; font-size: 12px; font-family: Arial, Helvetica, sans-serif;">FAHRİYE ÖZBAY</span></p>
              <p>(2010) Projects she worked in: Yeni Rakı Beykoz Family</p></td>
          </tr>
        </table><img src="img/menu_placeholder.gif" width="99" height="5">
                <table width="520" border="0" cellpadding="0" cellspacing="0">
          <tr>
            <td width="126" align="left" valign="top"><img src="../img/team_bos0.png" ></td>
            <td width="354" align="left" valign="top"><p><span style="color: #FFF; font-size: 12px; font-family: Arial, Helvetica, sans-serif;">İPEK TORUN</span></p>
              <p>(2009) Projects she worked in: Tekirdağ Rakı (Graphics Design), Yeni Rakı Duty (Free Graphics Design)</p></td>
          </tr>
        </table><img src="img/menu_placeholder.gif" width="99" height="5">
                <table width="520" border="0" cellpadding="0" cellspacing="0">
          <tr>
            <td width="126" align="left" valign="top"><img src="../img/team_bos0.png" ></td>
            <td width="354" align="left" valign="top"><p><span style="color: #FFF; font-size: 12px; font-family: Arial, Helvetica, sans-serif;">MURAT CELEP</span></p>
              <p>(2009-2010) Projects he worked in: Komili Olive Oil pet packaging and graphics design, Komili Olive Oil Premium Bottle Graphics Design</p></td>
          </tr>
        </table><img src="img/menu_placeholder.gif" width="99" height="5">
                <table width="520" border="0" cellpadding="0" cellspacing="0">
          <tr>
            <td width="126" align="left" valign="top"><img src="../img/team_bos0.png" ></td>
            <td width="354" align="left" valign="top"><p><span style="color: #FFF; font-size: 12px; font-family: Arial, Helvetica, sans-serif;">BAYRAM OKAN YAPICI</span></p>
              <p>(2007, 2009, 2012, 2016) Projects he worked in: Aspen Seperated Wall System Design, Komili Olive Oil (pet bottle), Tasarım Üssü Web Page Design, Tasarım Üssü Video Presentation</p></td>
          </tr>
        </table><img src="img/menu_placeholder.gif" width="99" height="5">
                <table width="520" border="0" cellpadding="0" cellspacing="0">
          <tr>
            <td width="126" align="left" valign="top"><img src="../img/team_bos0.png" ></td>
            <td width="354" align="left" valign="top"><p><span style="color: #FFF; font-size: 12px; font-family: Arial, Helvetica, sans-serif;">PINAR ÖNCEL</span></p>
              <p>(2005-2006) Projects she worked in: Doğanlar door handles (Tak Tak, Zümrüt, Park, Olea, Defne, Kavisli, Burç, Kobra, Dilara)</p></td>
          </tr>
        </table><img src="img/menu_placeholder.gif" width="99" height="5">
              </div>

  
<div class="menu"><a href="../haberler_bizden.php"><img src="img/EN.png" width="26" height="25" alt="tasarimussu_EN" /></a><img src="img/menu_placeholder.gif" alt="" width="60" height="25" /><img src="img/menu_studyo_H.png" alt="studyo" width="106" height="25" id="menu_studyo" /><img src="img/menu_placeholder.gif" alt="" width="27" height="25" /><a href="hizmetler.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('menu_hizmetler','','img/menu_hizmetler_H.png',1)"><img src="img/menu_hizmetler.png" alt="tasarimussu_Hizmetler" width="106" height="25" id="menu_hizmetler" /></a><img src="img/menu_placeholder.gif" alt="" width="35" height="25" /><a href="haberler_bizden.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('menu_haberler','','img/menu_haberler_H.png',1)"><img src="img/menu_haberler.png" alt="tasarimussu_Haberler" width="106" height="25" id="menu_haberler" /></a><img src="img/menu_placeholder.gif" alt="" width="27" height="25" /><a href="iletisim.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('menu_iletisim','','img/menu_iletisim_H.png',1)"><img src="img/menu_iletisim.png" alt="tasarimussu_�letisim" width="106" height="25" id="menu_iletisim" /></a><img src="img/menu_placeholder.gif" alt="" width="23" height="25" /><a href="
	
	
portfolyo_amb_50

.php"   onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('menu_portfolyo','','img/menu_portfolyo_H.png',1)"><img src="img/menu_portfolyo.png" alt="tasarimussu_Portfolyo" name="menu_portfolyo" width="224" height="25" id="menu_portfolyo" /></a></div>
  
  </div>
  
  <div class="turq" id="turq"><a href="http://www.turquality.com/" target="_blank"><img src="img/turquality_1.png" width="240" height="27" alt="turquality" /></a></div>
  
   </div>

  <div class="tt" id="tt"><a href="http://www.tumlesiktasarim.com" target="_blank"><img src="img/tt.png" width="18" height="84" /></a></div>

</body>
</html>
