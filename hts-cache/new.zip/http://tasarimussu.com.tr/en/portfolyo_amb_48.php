<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>TASARIMÜSSÜ - OĞUZ GIDA</title>
<meta name="description" content="TASARIM�SS� YASAL WEB S�TES�"/>
<meta name="keywords" content="Tasar�m,�r�n,Ambalaj,G�da,Marka Yaratma,Tasar�m Dan��manl���,Prototip ve Numune �retim Hizmetleri"/>
<link href="favicon.ico" rel="shortcut icon"/>
<link href="src/layout.css" rel="stylesheet">
<link href="src/general.css" rel="stylesheet">
<link href="src/slides.css" rel="stylesheet">
<link href="src/sidebarright_AMB.css" rel="stylesheet">
<link href="css/perfect-scrollbar.css" rel="stylesheet">
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
<script src="css/perfect-scrollbar.js"></script>
<script src="css/jquery.mousewheel.js"></script>

<style type="text/css">

.container {
	padding: 10px;
	height: 660px;
	width: 1024px;
	margin-top: 0px;
	margin-right: auto;
	margin-bottom: 0px;
	margin-left: auto;
	position: relative;
	top: 30px;
}
	
</style>

<script>
jQuery(document).ready(function ($) {
        "use strict";
        $('#Default').perfectScrollbar();
      });
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
    </script>


<script type="text/javascript">
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
</script>
</head>

<body style="overflow: " body onload="MM_preloadImages('img/menu_studyo_H.png','img/menu_haberler_H.png','img/menu_hizmetler_H.png','img/menu_iletisim_H.png')">

<form id="form1" name="form1" method="post" action="">
  <input type="hidden" name="ID" id="ID" />
  <input type="hidden" name="hiddenField" id="hiddenField" />
</form>
<div class="container">


<div class="sidebar_left">
  <p>Content for  class "sidebar_left" Goes Here</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
</div>


  <div class="sidebar_right" id="sidebar_right">
    <div id="Default" class="sidebar_right_content" >
    <form name="form1" method="post" action="">
              <p><a href="portfolyo_amb_50.php" title="CARTE D'OR">
        
CARTE D'OR</a></p>


                <p><a href="portfolyo_amb_49.php" title="BINBOA">
        
BINBOA</a></p>


                <p><a href="portfolyo_amb_48.php" title="JUSS">
        
JUSS</a></p>


                <p><a href="portfolyo_amb_47.php" title="İZMİR RAKISI">
        
İZMİR RAKISI</a></p>


                <p><a href="portfolyo_amb_46.php" title="OLD BAZAAR ">
        
OLD BAZAAR </a></p>


                <p><a href="portfolyo_amb_45.php" title="REGNUM ">
        
REGNUM </a></p>


                <p><a href="portfolyo_amb_44.php" title="YENİ RAKI MÜZEYYEN">
        
YENİ RAKI MÜZEYYEN</a></p>


                <p><a href="portfolyo_amb_43.php" title="İZMİR RAKISI GÖBEK">
        
İZMİR RAKISI GÖBEK</a></p>


                <p><a href="portfolyo_amb_42.php" title="ŞÖLEN İSTANBUL COLLECTION">
        
ŞÖLEN İSTANBUL COLLECTION</a></p>


                <p><a href="portfolyo_amb_41.php" title="ŞÖLEN OCTAVIA">
        
ŞÖLEN OCTAVIA</a></p>


                <p><a href="portfolyo_amb_40.php" title="ŞÖLEN MADLEN CHOCOLATE">
        
ŞÖLEN MADLEN CHOCOLATE</a></p>


                <p><a href="portfolyo_amb_39.php" title="HUMM ORGANIC">
        
HUMM ORGANIC</a></p>


                <p><a href="portfolyo_amb_38.php" title="ALGIDA TAHIN - BALBADEM">
        
ALGIDA TAHIN - BALBADEM</a></p>


                <p><a href="portfolyo_amb_37.php" title="TEKİRDAG KAVRULMUŞ ANASON">
        
TEKİRDAG KAVRULMUŞ ANASON</a></p>


                <p><a href="portfolyo_amb_36.php" title="YORSAN AYRAN">
        
YORSAN AYRAN</a></p>


                <p><a href="portfolyo_amb_35.php" title="TEKİRDAG RAKISI LIMITED ED.">
        
TEKİRDAG RAKISI LIMITED ED.</a></p>


                <p><a href="portfolyo_amb_34.php" title="BAILEYS">
        
BAILEYS</a></p>


                <p><a href="portfolyo_amb_33.php" title="YENİ RAKI 150 cl">
        
YENİ RAKI 150 cl</a></p>


                <p><a href="portfolyo_amb_32.php" title="IZMIR RAKISI">
        
IZMIR RAKISI</a></p>


                <p><a href="portfolyo_amb_31.php" title="SAFYA">
        
SAFYA</a></p>


                <p><a href="portfolyo_amb_30.php" title="BILL MATIK">
        
BILL MATIK</a></p>


                <p><a href="portfolyo_amb_29.php" title="ART MATIK">
        
ART MATIK</a></p>


                <p><a href="portfolyo_amb_28.php" title="CALVE">
        
CALVE</a></p>


                <p><a href="portfolyo_amb_27.php" title="ISTANBLUE">
        
ISTANBLUE</a></p>


                <p><a href="portfolyo_amb_26.php" title="KATIA">
        
KATIA</a></p>


                <p><a href="portfolyo_amb_25.php" title="BAHCIVAN BEMBEYAZ">
        
BAHCIVAN BEMBEYAZ</a></p>


                <p><a href="portfolyo_amb_24.php" title="BAHCIVAN FARM CHEESE">
        
BAHCIVAN FARM CHEESE</a></p>


                <p><a href="portfolyo_amb_23.php" title="FAWORİ PAINT PACKAGING">
        
FAWORİ PAINT PACKAGING</a></p>


                <p><a href="portfolyo_amb_22.php" title="YENİ RAKI RASTGELE">
        
YENİ RAKI RASTGELE</a></p>


                <p><a href="portfolyo_amb_21.php" title="BAHÇIVAN L.P.T">
        
BAHÇIVAN L.P.T</a></p>


                <p><a href="portfolyo_amb_20.php" title="TEKIRDAG N010">
        
TEKIRDAG N010</a></p>


                <p><a href="portfolyo_amb_19.php" title="EFES PİLSEN DRAFT">
        
EFES PİLSEN DRAFT</a></p>


                <p><a href="portfolyo_amb_18.php" title="EFES PİLSEN MALT">
        
EFES PİLSEN MALT</a></p>


                <p><a href="portfolyo_amb_17.php" title="EFES PİLSEN UNFILTERED">
        
EFES PİLSEN UNFILTERED</a></p>


                <p><a href="portfolyo_amb_16.php" title="EFES PİLSEN SPRING EDITION">
        
EFES PİLSEN SPRING EDITION</a></p>


                <p><a href="portfolyo_amb_15.php" title="ASIN FARM">
        
ASIN FARM</a></p>


                <p><a href="portfolyo_amb_14.php" title="KOMİLİ SPECIAL EDITION">
        
KOMİLİ SPECIAL EDITION</a></p>


                <p><a href="portfolyo_amb_13.php" title="BİNBOA">
        
BİNBOA</a></p>


                <p><a href="portfolyo_amb_12.php" title="LEZZO">
        
LEZZO</a></p>


                <p><a href="portfolyo_amb_11.php" title="YENİ RAKI BEYKOZ">
        
YENİ RAKI BEYKOZ</a></p>


                <p><a href="portfolyo_amb_10.php" title="ALTINBAŞ RAKI">
        
ALTINBAŞ RAKI</a></p>


                <p><a href="portfolyo_amb_09.php" title="HARE">
        
HARE</a></p>


                <p><a href="portfolyo_amb_08.php" title="OPET">
        
OPET</a></p>


                <p><a href="portfolyo_amb_07.php" title="BALKOVAN">
        
BALKOVAN</a></p>


                <p><a href="portfolyo_amb_06.php" title="KOMİLİ">
        
KOMİLİ</a></p>


                <p><a href="portfolyo_amb_05.php" title="TURKEY'S OLIVE OIL BOTTLE">
        
TURKEY'S OLIVE OIL BOTTLE</a></p>


                <p><a href="portfolyo_amb_04.php" title="TEKİRDAĞ RAKI">
        
TEKİRDAĞ RAKI</a></p>


                <p><a href="portfolyo_amb_03.php" title="TEKEL CİN">
        
TEKEL CİN</a></p>


                <p><a href="portfolyo_amb_02.php" title="1967 VOTKA">
        
1967 VOTKA</a></p>


                <p><a href="portfolyo_amb_01.php" title="YENİ RAKI">
        
YENİ RAKI</a></p>


              <p>&nbsp;</p>
      <p>&nbsp; </p>
          </FORM></div>
        <div class="sidebar_right_menu" >
      <p><span style="color: #CCC; font-size: 8pt; font-style: bold; "> <strong>PACKAGING DESIGN</strong></span></p>
      <p><span style="color: #CCC; font-size: 8pt; font-style: bold; "> <strong><a href="
	
	
portfolyo_urun_26

.php">PRODUCT DESIGN</a></strong><a href="portfolyo_AMB_efesU_220513.html"></a></span></p>
      <p><span style="color: #CCC; font-size: 8pt; font-style: bold; "> <strong><a href="portfolyo_deneysel.php">EXPERIMENTAL DESIGN</a></strong><a href="portfolyo_AMB_efesU_220513.html"></a></span></p>
    </div>
  </div>
  
  
  <div class="menu"><a href="../haberler_bizden.php"><img src="img/EN.png" width="26" height="25" alt="tasarimussu_EN" /></a><a href="studyo_felsefe.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('menu_studyo','','img/menu_studyo_H.png',1)"><img src="img/menu_placeholder.gif" alt="" width="60" height="25" /><img src="img/menu_studyo.png" alt="tasarimussu_studyo" width="106" height="25" id="menu_studyo" /></a><img src="img/menu_placeholder.gif" alt="" width="27" height="25" /><a href="hizmetler.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('menu_hizmetler','','img/menu_hizmetler_H.png',1)"><img src="img/menu_hizmetler.png" alt="tasarimussu_Hizmetler" width="106" height="25" id="menu_hizmetler" /></a><img src="img/menu_placeholder.gif" alt="" width="35" height="25" /><a href="haberler_bizden.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('menu_haberler','','img/menu_haberler_H.png',1)"><img src="img/menu_haberler.png" alt="tasarimussu_Haberler" width="106" height="25" id="menu_haberler" /></a><img src="img/menu_placeholder.gif" alt="" width="27" height="25" /><a href="iletisim.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('menu_iletisim','','img/menu_iletisim_H.png',1)"><img src="img/menu_iletisim.png" alt="" width="106" height="25" id="menu_iletisim" /></a><img src="img/menu_placeholder.gif" alt="" width="23" height="25" /><img src="img/menu_portfolyo_H.png" alt="" width="224" height="25" id="menu_portfolyo" /></div>
  
  <div class="content"><div id="slides">
     <img src="../img/juss/Juss.png" >
<img src="../img/juss/Juss1.png" >
<img src="../img/juss/Juss2.png" >
<img src="../img/juss/Juss3.png" >
     </div>
     <div class="numbering"><div id="slidesjs-log"><span class="slidesjs-slide-number">1</span><span style="color: #999; font-size: 14px; font-family: Arial, Helvetica, sans-serif;"> | 4</span></div>
</div>
<!-- End SlidesJS Required: Start Slides -->

  <!-- SlidesJS Required: Link to jQuery -->
  <script src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
  <!-- End SlidesJS Required -->

  <!-- SlidesJS Required: Link to jquery.slides.js -->
  <script src="js/jquery.slides.min.js"></script>
  <!-- End SlidesJS Required -->

  <!-- SlidesJS Required: Initialize SlidesJS with a jQuery doc ready --><!-- End SlidesJS Required -->

  <!-- SlidesJS Required: Initialize SlidesJS with a jQuery doc ready -->
  <script>
    $(function() {
      $('#slides').slidesjs({
        width: 1024,
        height: 690,
     callback: {
          loaded: function(number) {
            // Use your browser console to view log
            console.log('SlidesJS: Loaded with slide #' + number);

            // Show start slide in log
            $('#slidesjs-log .slidesjs-slide-number').text(number);
          },
          start: function(number) {
            // Use your browser console to view log
            console.log('SlidesJS: Start Animation on slide #' + number);
          },
          complete: function(number) {
            // Use your browser console to view log
            console.log('SlidesJS: Animation Complete. Current slide is #' + number);

            // Change slide number on animation complete
            $('#slidesjs-log .slidesjs-slide-number').text(number);
          }
        }
      });
    });
  </script>
  <!-- End SlidesJS Required -->
  </div>  
</div>


  <div class="turq" id="turq"><a href="http://www.turquality.com/" target="_blank"><img src="img/turquality_1.png" width="240" height="27" alt="turquality" /></a></div>

  <div class="tt" id="tt"><a href="http://www.tumlesiktasarim.com" target="_blank"><img src="img/tt.png" width="18" height="84" /></a></div>

</body>
</html>
