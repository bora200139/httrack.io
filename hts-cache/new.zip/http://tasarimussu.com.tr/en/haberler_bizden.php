
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=latin5">
<title>TASARIM&Uuml;SS&Uuml; - FROM US</title>
<meta name="description" content="TASARIM�SS� YASAL WEB S�TES�"/>
<meta name="keywords" content="Tasar�m,�r�n,Ambalaj,G�da,Marka Yaratma,Tasar�m Dan��manl���,Prototip ve Numune �retim Hizmetleri"/>

<link href="favicon.ico" rel="shortcut icon"/><link href="src/layout.css" rel="stylesheet">
<link href="src/general.css" rel="stylesheet">
<link href="src/slides.css" rel="stylesheet">
<link href="src/perfect-scrollbar.css" rel="stylesheet">

<link href="dist/lity.css" rel="stylesheet"/>


<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
<script src="src/jquery.mousewheel.js"></script>
<script src="src/perfect-scrollbar.js"></script>

<style type="text/css">



.container {
	padding: 10px;
	height: 660px;
	width: 1024px;
	margin-top: 0px;
	margin-right: auto;
	margin-bottom: 0px;
	margin-left: auto;
	position: relative;
	top: 30px;
}

.content {
	height: 70px;
	width: 70px;
	position: absolute;
	z-index:994;
	left:0px;
	right:0px;
	bottom:0px;
	top:0px;
	margin:auto;
}

.sidebar_right {
	height: 200px;
	width: 225px;
	z-index: 130;
	position: absolute;
	visibility: visible;
	right: 0px;
	margin-left: 0px;
	background-repeat: repeat;
	padding-top: 120px;
	white-space: normal;
	text-indent: 0;
	bottom: auto;
	vertical-align: bottom;
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	line-height: normal;
	color: #CCC;
    }
	
	
	.sidebar_left {
	height: 100px;
	width: 100px;
	z-index: 120;
	position: absolute;
	bottom: 10px;
	visibility: visible;
	left: auto;
	padding-top:100px;
	background-image: url(../img/logo.png);
	background-repeat: no-repeat;
	background-position: left bottom;
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	line-height: normal;
	color: #000;
	text-align: right;
}


</style>

<script>
jQuery(document).ready(function ($) {
        "use strict";
        $('#Default').perfectScrollbar();
      });
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
    </script>
    
    
</head>

<body style="overflow: "  body onload="MM_preloadImages('img/menu_studyo_H.png','img/menu_haberler_H.png','img/menu_hizmetler_H.png')">

<div class="container">

<div class="content">

<a href="//vimeo.com/161462229" data-lity id="link_to_content"><img src="../img/playSR.png" width="70" height="51" alt="play" /></a>


<!--<script >
$("document").ready(function() {
setTimeout(function() {
    $("#link_to_content").trigger('click');
},75);
});
</script>


 lightbox container hidden with CSS

<iframe src="https://player.vimeo.com/video/161462229" width="1024" height="576" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe> -->

</div>
<div class="sidebar_right" id="sidebar_right">
    
        <p><span style="color: #FFF; font-size: 12px; font-family: Arial, Helvetica, sans-serif;">TASARIMÜSSÜ SHOWREEL </br>FOR 25+ YEARS</span></p>
    
    
  <p> </p>
    </div>
    
<div class="sidebar_left"></div>

  <div id="submenuhaber">
    <p><strong><span style="color: #FFF; font-size: 10px; font-family: Arial, Helvetica, sans-serif;">FROM US</span></strong></p>
    <p><a href="haberler_basin.php">PRESS</a></p>
    <p><a href="haberler_internet.php">INTERNET</a></p>
    <p><a href="haberler_bultenler.php">BULLETINS</a></p>
  </div>

<div id="Default" class="contentHolder"></div>

  
<div class="menu"><a href="../haberler_bizden.php"><img src="img/EN.png" width="26" height="25" alt="tasarimussu_EN" /></a><a href="studyo_felsefe.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('menu_studyo','','img/menu_studyo_H.png',1)"><img src="img/menu_placeholder.gif" alt="" width="60" height="25" /><img src="img/menu_studyo.png" alt="tasarimussu_studyo" width="106" height="25" id="menu_studyo" /></a><img src="img/menu_placeholder.gif" alt="" width="27" height="25" /><a href="hizmetler.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('menu_hizmetler','','img/menu_hizmetler_H.png',1)"><img src="img/menu_hizmetler.png" alt="tasarimussu_hizmetler" width="106" height="25" id="menu_hizmetler" /></a><img src="img/menu_placeholder.gif" alt="" width="35" height="25" /><img src="img/menu_haberler_H.png" alt="" width="106" height="25" id="menu_haberler" /><img src="img/menu_placeholder.gif" alt="" width="27" height="25" /><a href="iletisim.php"><img src="img/menu_iletisim.png" alt="tasarimussu_iletisim" width="106" height="25" id="menu_iletisim" /></a><img src="img/menu_placeholder.gif" alt="" width="23" height="25" /><a href="
	
	
portfolyo_amb_50

.php"  onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('menu_portfolyo','','img/menu_portfolyo_H.png',1)"><img src="img/menu_portfolyo.png" alt="tasarimussu_portfolyo" name="menu_portfolyo" width="224" height="25" id="menu_portfolyo" /></a></div>


<img src="../img/Haberler/SR.png" > 
  
  </div>
  
  <div class="turq" id="turq"><a href="http://www.turquality.com/" target="_blank"><img src="img/turquality_1.png" width="240" height="27" alt="turquality" /></a></div>
  
   </div>

  <div class="tt" id="tt"><a href="http://www.tumlesiktasarim.com" target="_blank"><img src="img/tt.png" width="18" height="84" /></a></div>
<script src="vendor/jquery.js"></script>
<script src="dist/lity.js"></script>
<script src="assets/prism.js"></script>
</body>
</html>
