
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>TASARIMÜSSÜ - CONTACT</title>
<meta name="description" content="TASARIMÜSSÜ YASAL WEB SİTESİ"/>
<meta name="keywords" content="Tasarım,Ürün,Ambalaj,Gıda,Marka Yaratma,Tasarım Danışmanlığı,Prototip ve Numune Üretim Hizmetleri"/>

<link href="favicon.ico" rel="shortcut icon"/><link href="src/layout.css" rel="stylesheet">
<link href="src/general.css" rel="stylesheet">
<link href="src/slides.css" rel="stylesheet">
<link href="src/sidebarright_AMB.css" rel="stylesheet">
<link href="src/perfect-scrollbar.css" rel="stylesheet">
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
<script src="src/jquery.mousewheel.js"></script>
<script src="src/perfect-scrollbar.js"></script>

<style type="text/css">

.container {
	padding: 10px;
	height: 660px;
	width: 1024px;
	margin-top: 0px;
	margin-right: auto;
	margin-bottom: 0px;
	margin-left: auto;
	position: relative;
	top: 30px;
}
</style>

<script>
jQuery(document).ready(function ($) {
        "use strict";
        $('#Default').perfectScrollbar();
      });
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
    </script>
    
    
</head>

<body style="overflow: "  body onload="MM_preloadImages('img/menu_studyo_H.png','img/menu_haberler_H.png','img/menu_hizmetler_H.png','img/menu_iletisim_H.png')">

<div class="container">

    <div class="sidebar_left">
    <p>&nbsp;</p>
    <p><span style="color: #FFF; font-size: 12px; font-family: Arial, Helvetica, sans-serif;">TASARIMÜSSÜ LTD. ŞTİ</span></p>
 	<p><span style="color: #CCC; font-size: 12px; font-family: Arial, Helvetica, sans-serif;line-height: 18px;">
    Muhittin Sokak<br />
    Akçer Çıkmazı 12|1<br />
    34810<br />
    Kanlıca - İstanbul<br />
  	T. +90 (216) 680 11 87<br />
    F. +90 (216) 680 11 85</span></p>
  <p><a href="mailto:info@tasarimussu.com.tr">info@tasarimussu.com.tr</a></p>
</div>


    <div id="Default" class="contentHolder">
    
      <p>&nbsp;</p>
<iframe width="800" height="800" frameborder="0" scrolling="yes" marginheight="0" marginwidth="0" src="http://maps.google.de/maps?f=q&amp;source=s_q&amp;hl=en&amp;geocode=&amp;q=Beykoz,+Ak%C3%A7er+Sokak,+Istanbul,+Turkey&amp;aq=0&amp;oq=akcer+cikmazi&amp;sll=51.151786,10.415039&amp;sspn=9.611026,26.784668&amp;ie=UTF8&amp;hq=&amp;hnear=Kanl%C4%B1ca+Mh.,+Ak%C3%A7er+Sk,+%C4%B0stanbul%2FBeykoz,+Turkey&amp;ll=41.100511,29.067113&amp;spn=0.002818,0.006539&amp;t=m&amp;z=17&amp;output=embed"></iframe><br />

    </div>
        
     <div class="menu"><a href="../haberler_bizden.php"><img src="img/EN.png" width="26" height="25" alt="tasarimussu_EN" /></a><a href="studyo_felsefe.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('menu_studyo','','img/menu_studyo_H.png',1)"><img src="img/menu_placeholder.gif" alt="" width="60" height="25" /><img src="img/menu_studyo.png" alt="tasarimussu_studyo" width="106" height="25" id="menu_studyo" /></a><img src="img/menu_placeholder.gif" width="27" height="25" /><a href="hizmetler.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('menu_hizmetler','','img/menu_hizmetler_H.png',1)"><img src="img/menu_hizmetler.png" alt="tasarimussu_Hizmetler" width="106" height="25" id="menu_hizmetler" /></a><img src="img/menu_placeholder.gif" width="35" height="25" /><a href="haberler_bizden.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('menu_haberler','','img/menu_haberler_H.png',1)"><img src="img/menu_haberler.png" alt="tasarimussu_Haberler" width="106" height="25" id="menu_haberler" /></a><img src="img/menu_placeholder.gif" width="27" height="25" /><img src="img/menu_iletisim_H.png" alt="" width="106" height="25" id="menu_iletisim" /><img src="img/menu_placeholder.gif" width="23" height="25" /><a href="
	
	
portfolyo_amb_50

.php"   onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('menu_portfolyo','','img/menu_portfolyo_H.png',1)"><img src="img/menu_portfolyo.png" alt="" name="menu_portfolyo" width="224" height="25" id="menu_portfolyo" /></a></div>
  
</div>
  
  <div class="turq" id="turq"><a href="http://www.turquality.com/" target="_blank"><img src="img/turquality_1.png" width="240" height="27" alt="turquality" /></a></div>
  
   </div>

  <div class="tt" id="tt"><a href="http://www.tumlesiktasarim.com" target="_blank"><img src="img/tt.png" width="18" height="84" /></a></div>

</body>
</html>
