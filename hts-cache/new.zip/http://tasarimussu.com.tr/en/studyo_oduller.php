
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>TASARIMÜSSÜ - AWARDS</title>
<meta name="description" content="TASARIMÜSSÜ YASAL WEB SİTESİ"/>
<meta name="keywords" content="Tasarım,Ürün,Ambalaj,Gıda,Marka Yaratma,Tasarım Danışmanlığı,Prototip ve Numune Üretim Hizmetleri"/>

<link href="favicon.ico" rel="shortcut icon"/><link href="src/layout.css" rel="stylesheet">
<link href="src/general.css" rel="stylesheet">
<link href="src/slides.css" rel="stylesheet">
<link href="src/perfect-scrollbar.css" rel="stylesheet">
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
<script src="src/jquery.mousewheel.js"></script>
<script src="src/perfect-scrollbar.js"></script>

<style type="text/css">

.container {
	padding: 10px;
	height: 660px;
	width: 1024px;
	margin-top: 0px;
	margin-right: auto;
	margin-bottom: 0px;
	margin-left: auto;
	position: relative;
	top: 30px;
}
</style>

<script>
jQuery(document).ready(function ($) {
        "use strict";
        $('#Default').perfectScrollbar();
      });
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
    </script>
    
    
</head>

<body style="overflow: "  body onload="MM_preloadImages('img/menu_studyo_H.png','img/menu_haberler_H.png','img/menu_hizmetler_H.png','img/menu_iletisim_H.png')">

<div class="container">

<div class="sidebar_left"></div>

  <div id="submenu">
    <p><a href="studyo_felsefe.php">PHILOSOPHY</a></p>
    <p><a href="studyo_biyo.php">BIOGRAPHIES</a></p>
    <p><a href="studyo_musteriler.php">CUSTOMERS</a></p>
    <p><strong><span style="font-family: Arial, Helvetica, sans-serif; font-size: 10px; color: #FFF">AWARDS</span></strong></p>
    <p>&nbsp;</p>
    
</div>

  <div id="Default" class="contentHolder">
  <form name="form1" method="post" action="">
 
          <p><span style="color: #fff; font-size: 14px; font-family: Arial, Helvetica, sans-serif;">2016 Awards</span></p>
      <p><p>Red Dot Design Award 2016 - Istanblue Vodka </p>
<p>WPO Worldstar 2016 (WPO:World Packaging Organisation), Istanblue Vodka </p>
<p>WPO Worldstar 2016 (WPO:World Packaging Organisation), Safya - Sunflower Oil </p>
<p>Crescent and Stars for Packaging 2016, Drink Category, Competence Award - Yeni Raki 150 cl </p>
<p>Crescent and Stars for Packaging 2016, Drink Category, Bronze Award - Izmir Rakisi </p>
<p>Design Turkey 2016, Good Design Award - Eti Sticks </p>
<p>Design Turkey 2016, Good Design Award - Safya Sunflower Oil </p>
<p>Asiastar 2016 Award, Mey Içki - Izmir Rakisi </p>
<p>Asiastar 2016 Award, Mey Içki - Yeni Raki 150 cl </p>
</p>
          <p><span style="color: #fff; font-size: 14px; font-family: Arial, Helvetica, sans-serif;">2015 Awards</span></p>
      <p><p>WPO Worldstar 2015 (WPO:World Packaging Organisation) - Tekirdag No 10</p>
<p>Crescent and Stars for Packaging 2015, Drink Category,Competence Award- Istanblue Vodka </p>
<p>Crescent and Stars for Packaging 2015, Food Category,Competence Award- Safya - Sunflower Oil </p>
<p>Crescent and Stars for Packaging 2015, Graphic Design Catergory,Competence Award- Yeni Raki Rastgele </p>
<p>Asiastar 2015 Award, Safya - Sunflower Oil </p>
<p>Asiastar 2015 Award, Istanblue Vodka </p></p>
          <p><span style="color: #fff; font-size: 14px; font-family: Arial, Helvetica, sans-serif;">2014 Awards</span></p>
      <p><p>WPO Worldstar 2014 (WPO:World Packaging Organisation) - Asın Farm Olive Oil </p><p>Design Turkey 2014 - Good Design Award - Tekirdag No 10 </p>
<p>Crescent and Stars for Packaging 2014, Drink  Category,Bronze Award- Tekirdag No 10 </p>
<p>Design Turkey 2014 - Good Design Award - Balkovan</p>
<p>Crescent and Stars for Packaging 2014, Food Category,Bronze Award- Bahçivan Delicious Cheese Balls</p>
<p>Observeur du design '14 Label - Efes Pilsen Draft Beer Package</p>
<p>Observeur du design '14 Label - Efes Malt Beer Package</p></p>
          <p><span style="color: #fff; font-size: 14px; font-family: Arial, Helvetica, sans-serif;">2013 Awards</span></p>
      <p> <p>WPO Worldstar 2013 (World Packaging Organization) - Efes Pilsen Spring Edition</p> 

 <p>German Design Award 2013 Nominee - Tekirdag Raki Family</p>

 <p>Observeur du design '13 Label - Eti Milky Chocolatte</p>

 <p>Observeur du design '13 Label - Efes Pilsen Spring Edition</p>

 <p>Observeur du design '13 Label - Efes Pilsen Unfiltered</p>

 <p>Observeur du design '13 Label - Komili Premium Olive Oil Bottle Packaging</p>

<p>Crescent and Stars for Packaging 2013, Gold Award - Asin Farm Olive Oil Packaging</p>

<p>Crescent and Stars for Packaging 2013, Silver Award - Binboa Limited Edition</p>

<p>Crescent and Stars for Packaging 2013, Silver Award - Efes Malt Beer Packaging</p>
<p>Crescent and Stars for Packaging 2013, Silver Award - Efes Pilsen Draft Beer Packaging</p></p>
          <p><span style="color: #fff; font-size: 14px; font-family: Arial, Helvetica, sans-serif;">2012 Awards</span></p>
      <p><p>Crescent and Stars for Packaging 2012, Competence Award - Efes Pilsen Spring Edition</p>

<p>Crescent and Stars for Packaging 2012, Silver Award - Efes Pilsen Unfiltered</p>

<p>Observeur du design '12 Label - Tekirdag Raki Family</p>

<p>Observeur du design '12 Label - Eti Tutku Milky Chocolatte
</p>
<p>Observeur du design '12 Label - Eti Karam Bitter Chocolatte</p>

<p>Design Turkey 2012 - Superior Design Award - Komili Premium Olive Oil Bottle</p>

<p>Design Turkey 2012 - Good Design Award - Binboa Vodka Packaging</p>

<p>Design Turkey 2012 - Good Design Award - Asin Farm Glass Olive Oil Bottle</p></p>
          <p><span style="color: #fff; font-size: 14px; font-family: Arial, Helvetica, sans-serif;">2011 Awards</span></p>
      <p><p>Crescent and Stars for Packaging 2011, Drink Category Golden Award - Tekirdag Raki Family</p>

<p>Crescent and Stars for Packaging 2011, Food Category, Golden Award - Komili Premium Olive Oil Bottle Packaging</p>

<p>Crescent and Stars for Packaging 2011, Graphics Design Category, Silver Award - Lezzo</p>

<p>Crescent and Stars for Packaging 2011, Drink Category, Golden Award - Binboa Vodka</p>

<p>Crescent and Stars for Packaging 2011, Graphics Design Category, Competence Award - Hare Mothers Day Limited Edition</p>

<p>Red Dot Design Awards 2011 - Tekirdag Raki Family</p>

<p>24. TSE Golden Packaging Award, 2011 - Komili Premium Olive Oil Bottle Packaging</p>

<p>24. TSE Golden Packaging Award, 2011 - Lezzo</p>

<p>24. TSE Golden Packaging Award, 2011 - Binboa Vodka</p>

<p>24. TSE Golden Packaging Award, 2011 - Hare New Year Limited Edition</p>

<p>WPO Worldstar 2011 (WPO: World Packaging Organisation) - Komili Premium Olive Oil Bottle Packaging</p>

<p>WPO Worldstar 2011 (WPO: World Packaging Organisation) - Binboa Vodka</p></p>
          <p><span style="color: #fff; font-size: 14px; font-family: Arial, Helvetica, sans-serif;">2010 Awards</span></p>
      <p><p>23. TSE Golden Packaging - Komili Olive Oil Pet Bottle</p>

<p>23. TSE Golden Packaging - Opet Lube Oil Packaging</p>

<p>23. TSE Golden Packaging - Altinbas Rakisi</p>

<p>Design Turkey 'Good Design Award'- Altinbas Rakisi</p>

<p>Design Turkey 'Good Design Award' - Yeni Raki Beykoz Family</p>

<p>Design Turkey 'Good Design Award' - Lazer Door Handle</p>

<p>WPO Worldstar 2010 (World Packaging Organisation) - Opet Lube Oil</p>

<p>WPO Worldstar 2010 (World Packaging Organisation) - Turkey's Olive Oil Bottle</p>

<p>Crescent and Stars for Packaging 2010, Drink Category Golden Award - Altinbas Rakisi</p>

<p>Crescent and Stars for Packaging 2010, Drink Category Silver Award - Yeni Raki Beykoz</p>

<p>Crescent and Stars for Packaging 2010, Food Category Silver Award - Turkey's Olive Oil Bottle</p>

<p>Crescent and Stars for Packaging 2010, Food Category Bronze Award - Komili Olive Oil Pet Bottle</p>

<p>Crescent and Stars for Packaging 2010, Automotive Supplies Golden Award - Opet Lube Oil Packaging</p></p>
          <p><span style="color: #fff; font-size: 14px; font-family: Arial, Helvetica, sans-serif;">2009 Awards</span></p>
      <p><p>22. TSE Golden Packaging Award - Yeni Raki Duty Free Box</p>

<p>22. TSE Golden Packaging Award - Tekirdag Raki Trakya Family</p>

<p>WPO Worldstar 2009 (World Packaging Organisation)- Tekirdag Raki Trakya Series</p>

<p>Pentawards Nomination - Tekirdag Rakisi Golden Series</p>

<p>Observeur du design '09 Label- Yeni Raki Bottle</p>
</p>
          <p><span style="color: #fff; font-size: 14px; font-family: Arial, Helvetica, sans-serif;">2008 Awards</span></p>
      <p><p>WPO Worldstar 2008 (World Packaging Organisation) - Tekirdag Raki</p>

<p>21. TSE Golden Packaging - Tekirdag Raki</p>

<p>Design Turkey 2008 'Good Design Award' - Yeni Raki Bottle</p>

<p>Design Turkey 2008 'Good Design Award' - Tekel Cin Bottle</p>

<p>Design Turkey 2008 'Good Design Award' - Votka 1967 Bottle</p>

<p>Design Turkey 2008 'Good Design Award' - Tekirdag Raki Bottle</p></p>
          <p><span style="color: #fff; font-size: 14px; font-family: Arial, Helvetica, sans-serif;">Awards from 2007 and Before</span></p>
      <p><p>2005</p>

<p>18. TSE Golden Packaging - Yeni Raki Bottle</p>

<p>2003</p>

<p>Coverings Special Recognition Award</p>

<p>1996</p>

<p>Paneldus 1. Bathroom Design Competition Winner Award</p>

<p>Adres Furniture Design Award</p></p>
    </FORM>

    </div>

  
 <div class="menu"><a href="../haberler_bizden.php"><img src="img/EN.png" width="26" height="25" alt="tasarimussu_EN" /></a><img src="img/menu_placeholder.gif" alt="" width="60" height="25" /><img src="img/menu_studyo_H.png" alt="studyo" width="106" height="25" id="menu_studyo" /><img src="img/menu_placeholder.gif" alt="" width="27" height="25" /><a href="hizmetler.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('menu_hizmetler','','img/menu_hizmetler_H.png',1)"><img src="img/menu_hizmetler.png" alt="tasarimussu_Hizmetler" width="106" height="25" id="menu_hizmetler" /></a><img src="img/menu_placeholder.gif" alt="" width="35" height="25" /><a href="haberler_bizden.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('menu_haberler','','img/menu_haberler_H.png',1)"><img src="img/menu_haberler.png" alt="tasarimussu_Haberler" width="106" height="25" id="menu_haberler" /></a><img src="img/menu_placeholder.gif" alt="" width="27" height="25" /><a href="iletisim.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('menu_iletisim','','img/menu_iletisim_H.png',1)"><img src="img/menu_iletisim.png" alt="tasarimussu_İletisim" width="106" height="25" id="menu_iletisim" /></a><img src="img/menu_placeholder.gif" alt="" width="23" height="25" /><a href="
	
	
portfolyo_amb_50

.php"   onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('menu_portfolyo','','img/menu_portfolyo_H.png',1)"><img src="img/menu_portfolyo.png" alt="tasarimussu_Portfolyo" name="menu_portfolyo" width="224" height="25" id="menu_portfolyo" /></a></div>
  
  </div>
  
  <div class="turq" id="turq"><a href="http://www.turquality.com/" target="_blank"><img src="img/turquality_1.png" width="240" height="27" alt="turquality" /></a></div>
  
   </div>

  <div class="tt" id="tt"><a href="http://www.tumlesiktasarim.com" target="_blank"><img src="img/tt.png" width="18" height="84" /></a></div>

</body>
</html>
