<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>TASARIM&Uuml;SS&Uuml; - BULTENLER</title>
<meta name="description" content="TASARIM�SS� YASAL WEB S�TES�"/>
<meta name="keywords" content="Tasar�m,�r�n,Ambalaj,G�da,Marka Yaratma,Tasar�m Dan��manl���,Prototip ve Numune �retim Hizmetleri"/>

<link href="favicon.ico" rel="shortcut icon"/><link href="src/layout.css" rel="stylesheet">
<link href="src/general.css" rel="stylesheet">
<link href="src/slides.css" rel="stylesheet">
<link href="src/sidebarright_AMB.css" rel="stylesheet">
<link href="src/perfect-scrollbar.css" rel="stylesheet">
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
<script src="src/jquery.mousewheel.js"></script>
<script src="src/perfect-scrollbar.js"></script>

<style type="text/css">

.container {
	padding: 10px;
	height: 660px;
	width: 1024px;
	margin-top: 0px;
	margin-right: auto;
	margin-bottom: 0px;
	margin-left: auto;
	position: relative;
	top: 30px;
}

</style>

<script>
jQuery(document).ready(function ($) {
        "use strict";
        $('#Default').perfectScrollbar();
      });
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
    </script>
    
    
</head>

<body style="overflow: "  body onload="MM_preloadImages('img/menu_studyo_H.png','img/menu_haberler_H.png','img/menu_hizmetler_H.png','img/menu_iletisim_H.png')">

<div class="container">

<div class="sidebar_left"></div>

  <div id="submenuhaber">
    <p><a href="haberler_bizden.php">B�ZDEN HABERLER</a></p>
    <p><a href="haberler_basin.php">BASINDA &Ccedil;IKAN</a></p>
    <p><a href="haberler_internet.php">�NTERNETTE &Ccedil;IKAN</a></p>
    <p><strong><span style="color: #FFF; font-size: 10px; font-family: Arial, Helvetica, sans-serif;">B&Uuml;LTENLER</span></strong></p>
  </div>


<div id="Default" class="contentHolder">

<form name="form1" method="post" action="">
                   
<p>&nbsp;</p>

 
 
  <p><a href="http://www.tasarimussu.com.tr/pdf/ambalajin_ay_yildizlari_basin_bulteni.doc" target="_blank">Tasarim Üssü 2011 Ambalajın Ay Yıldızları Ödülü Basın Bülteni (word)</a></p>
    <p><a href="http://www.tasarimussu.com.tr/pdf/tasarimussu_fransadan_odul_basin_bulteni.doc" target="_blank">Tasarım Üssüne Fransa'dan Ödül (word)</a></p>
    <p><a href="http://www.tasarimussu.com.tr/pdf/reddot_odul_bulteni.doc" target="_blank">Reddot Ödül Bülteni (word)</a></p>
    <p><a href="http://www.tasarimussu.com.tr/pdf/binboavotka_%20basin_%20bulteni.doc" target="_blank">Binboa Votka Basınn Bülteni (word)</a></p>
    <p><a href="http://www.tasarimussu.com.tr/pdf/tasarimussu_eti_tutkukaram.doc" target="_blank">Tasarim Üssü Eti Tutku ve Karam Basın Bülteni (Word)</a></p>
    <p><a href="http://www.tasarimussu.com.tr/pdf/tasarimussu_binboavodka.doc" target="_blank">Tasarim Üssü Binboa Vodka Basın Bülteni (word)</a></p>
    <p><a href="http://www.tasarimussu.com.tr/pdf/rakisisesiodulleri_bulten_b.doc" target="_blank">Tasarim Üssu Rakı Şişesi Ödülleri Basın Bülteni (word)</a></p>
    <p><a href="http://www.tasarimussu.com.tr/pdf/gamzeguven_DDNfinal.doc" target="_blank">Gamze Guven DDN final (word)</a></p>
    <p><a href="http://www.tasarimussu.com.tr/pdf/bulten_05.doc" target="_blank">Tasarim Üssü Bülteni 5 (word)</a></p>
    <p><a href="http://www.tasarimussu.com.tr/pdf/eko.doc" target="_blank">Tasarim Üssü Eko (word)</a></p>
    <p><a href="http://www.tasarimussu.com.tr/pdf/newsletter_122008.pdf" target="_blank">Tasarim Üssü Newsletter 2008 (word)</a></p>
  </FORM>
</div>

  
    <div class="menu"><a href="en/haberler_bizden.php"><img src="img/EN.png" width="26" height="25" alt="tasarimussu_EN" /></a><a href="studyo_felsefe.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('menu_studyo','','img/menu_studyo_H.png',1)"><img src="img/menu_placeholder.gif" alt="" width="60" height="25" /><img src="img/menu_studyo.png" alt="tasarimussu_studyo" width="106" height="25" id="menu_studyo" /></a><img src="img/menu_placeholder.gif" width="27" height="25" /><a href="hizmetler.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('menu_hizmetler','','img/menu_hizmetler_H.png',1)"><img src="img/menu_hizmetler.png" alt="tasarimussu_hizmetler" width="106" height="25" id="menu_hizmetler" /></a><img src="img/menu_placeholder.gif" width="35" height="25" /><img src="img/menu_haberler_H.png" alt="" width="106" height="25" id="menu_haberler" /><img src="img/menu_placeholder.gif" width="27" height="25" /><a href="iletisim.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('menu_iletisim','','img/menu_iletisim_H.png',1)"><img src="img/menu_iletisim.png" alt="tasarimussu_iletisim" width="106" height="25" id="menu_iletisim" /></a><img src="img/menu_placeholder.gif" width="23" height="25" /><a href="
	
	
portfolyo_amb_50

.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('menu_portfolyo','','img/menu_portfolyo_H.png',1)"><img src="img/menu_portfolyo.png" alt="tasarimussu_portfolyo" name="menu_portfolyo" width="224" height="25" id="menu_portfolyo" /></a></div>
  
  </div>
  
  <div class="turq" id="turq"><a href="http://www.turquality.com/" target="_blank"><img src="img/turquality_1.png" width="240" height="27" alt="turquality" /></a></div>
  
   </div>

  <div class="tt" id="tt"><a href="http://www.tumlesiktasarim.com" target="_blank"><img src="img/tt.png" width="18" height="84" /></a></div>

</body>
</html>
